cls

::Instalador de atajos de L�nea de Comandos para Windows XP (Home o Professional)
::Sirve solamente para Windows XP Service Pack 3 en su instalaci�n completa
::� 2010 - � DI-DA-DO Computaci�n
::Buenos Aires, Argentina
::didadocom@yahoo.com
::30/07/2010

@echo off

color 0F

title L�nea de Comandos de Windows XP

echo.
echo ------------------------ DI-DA-DO Computaci�n ------------------------
echo.
echo.            Instalador de L�nea de Comandos de Windows XP
echo.
echo ----------------------------------------------------------------------

If Not Exist "%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP" (md "%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP")

echo.001 - Append
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Append.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k append /?" /d:"Permite que los programas abran archivos que se encuentren en los directorios especificados como si estuviesen en el directorio actual"

echo ----------------------------------------------------------------------

echo.002 - Arp
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Arp.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k arp /?" /d:"Muestra y modifica las tablas de conversi�n de direcciones IP en direcciones f�sicas que utiliza el protocolo de resoluci�n de direcciones (ARP)"

echo ----------------------------------------------------------------------

echo.003 - Asr_fmt 
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Asr_fmt.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k asr_fmt /?" /d:"Recuperaci�n autom�tica del sistema de Windows"

echo ----------------------------------------------------------------------

echo.004 - Asr_ldm
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Asr_ldm.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k asr_ldm /?" /d:"Utililidad ASR Administrador de discos l�gicos"

echo ----------------------------------------------------------------------

echo.005 - Assoc
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Assoc.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k assoc /?" /d:"Muestra o modifica las asociaciones de extensiones de archivos"

echo ----------------------------------------------------------------------

echo.006 - At
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\At.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k at /?" /d:"Programa la ejecuci�n de comandos y programas en un equipo a una hora y fecha especificadas"

echo ----------------------------------------------------------------------

echo.007 - Atmadm
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Atmadm.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k atmadm /?" /d:"Monitorea conexiones y direcciones que son registradas por el Administrador de llamadas ATM en un modo de transferencia as�ncrono por red (ATM)"

echo ----------------------------------------------------------------------

echo.008 - Attrib
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Attrib.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k attrib /?" /d:"Muestra o cambia los atributos de un archivo"

echo ----------------------------------------------------------------------

echo.009 - Auditusr
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Auditusr.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k auditusr /?" /d:"Establece la directiva de auditor�as para cada usuario"

echo ----------------------------------------------------------------------

echo.010 - Blastcln
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Blastcln.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k blastcln /?" /d:"Herramienta de remoci�n de virus Blaster-Natchi"

echo ----------------------------------------------------------------------

echo.011 - Bootcfg
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Bootcfg.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k bootcfg /?" /d:"Para configurar, consultar, cambiar o eliminar la configuraci�n de la entrada de inicio en el archivo Boot.ini"

echo ----------------------------------------------------------------------

echo.012 - Break
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Break.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k break /?" /d:"Activa o desactiva Ctrl+C extendido en MS-DOS"

echo ----------------------------------------------------------------------

echo.013 - Cacls
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Cacls.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k cacls /?" /d:"Muestra o modifica las Listas de Control de Acceso (ACL) de archivos"

echo ----------------------------------------------------------------------

echo.014 - Call
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Call.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k call /?" /d:"Llama a un archivo por lotes desde otro"

echo ----------------------------------------------------------------------

echo.015 - Cd
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Cd.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k cd /?" /d:"Muestra el nombre del directorio actual o cambia de directorio"

echo ----------------------------------------------------------------------

echo.016 - Chcp
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Chcp.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k chcp /?" /d:"Muestra o establece el n�mero de la tabla de c�digos activa"

echo ----------------------------------------------------------------------

echo.017 - Chdir
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Chdir.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k chdir /?" /d:"Muestra el nombre del directorio actual o cambia de directorio"

echo ----------------------------------------------------------------------

echo.018 - Chkdsk
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Chkdsk.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k chkdsk /?" /d:"Comprueba un disco y muestra un informe de estado"

echo ----------------------------------------------------------------------

echo.019 - Chkntfs
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Chkntfs.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k chkntfs /?" /d:"Muestra o modifica la comprobaci�n del disco en el tiempo de inicio"

echo ----------------------------------------------------------------------

echo.020 - Cipher
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Cipher.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k cipher /?" /d:"Muestra o altera el cifrado de directorios (archivos) en particiones NTFS"

echo ----------------------------------------------------------------------

echo.021 - Cls
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Cls.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k cls /?" /d:"Borra la pantalla"

echo ----------------------------------------------------------------------

echo.022 - Clspack
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Clspack.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k clspack /?" /d:"Herramienta que se utiliza para crear un archivo nuevo Classes.zip en el \% Windir% \ Java \ Classes"

echo ----------------------------------------------------------------------

echo.023 - Cmd
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Cmd.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k cmd /?" /d:"Inicia una nueva instancia del Int�rprete de Comandos de Windows XP"

echo ----------------------------------------------------------------------

echo.024 - Cmstp
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Cmstp.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k cmstp /?" /d:"Instalador de perfiles de Connection Manager"

echo ----------------------------------------------------------------------

echo.025 - Color
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Color.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k color /?" /d:"Configura los colores predeterminados de primer y segundo plano de la consola"

echo ----------------------------------------------------------------------

echo.026 - Command
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Command.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k command /?" /d:"Inicia una nueva instancia del procesador de comandos MS-DOS"

echo ----------------------------------------------------------------------

echo.027 - Comp
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Comp.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k comp /?" /d:"Compara el contenido de dos archivos o conjuntos de archivos"

echo ----------------------------------------------------------------------

echo.028 - Compact
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Compact.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k compact /?" /d:"Muestra o altera la compresi�n de los archivos en particiones NTFS"

echo ----------------------------------------------------------------------

echo.029 - Convert
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Convert.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k convert /?" /d:"Convierte vol�menes FAT a vol�menes NTFS"

echo ----------------------------------------------------------------------

echo.030 - Convlog
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Convlog.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k convlog /?" /d:"Convierte archivos de registro de IIS al formato com�n de archivos de registro NCSA"

echo ----------------------------------------------------------------------

echo.031 - Copy
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Copy.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k copy /?" /d:"Copia uno o m�s archivos en otra ubicaci�n"

echo ----------------------------------------------------------------------

echo.032 - Cscript
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Cscript.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k cscript /?" /d:"Versi�n de la l�nea de comandos de Windows Script Host que ofrece opciones de l�nea de comandos para establecer las propiedades de secuencia de comandos"

echo ----------------------------------------------------------------------

echo.033 - Date
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Date.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k date /?" /d:"Muestra o establece la fecha"

echo ----------------------------------------------------------------------

echo.034 - Debug
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Debug.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k debug /?" /d:"Herramienta de edici�n y comprobaci�n de programas"

echo ----------------------------------------------------------------------

echo.035 - Defrag
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Defrag.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k defrag /?" /d:"Busca y consolida los archivos de inicio fragmentados, los archivos de datos y las carpetas de los vol�menes locales"

echo ----------------------------------------------------------------------

echo.036 - Del
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Del.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k del /?" /d:"Elimina uno o m�s archivos"

echo ----------------------------------------------------------------------

echo.037 - Diantz
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Diantz.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k diantz /?" /d:"Herramienta para comprimir archivos e insertarlos en un archivo contenedor (.cab). Similar a Makecab"

echo ----------------------------------------------------------------------

echo.038 - Dir
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Dir.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k dir /?" /d:"Muestra la lista de subdirectorios y archivos de un directorio"

echo ----------------------------------------------------------------------

echo.039 - Diskcomp
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Diskcomp.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k diskcomp /?" /d:"Compara el contenido de dos disquetes"

echo ----------------------------------------------------------------------

echo.040 - Diskcopy
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Diskcopy.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k diskcopy /?" /d:"Copia el contenido de un disco en otro"

echo ----------------------------------------------------------------------

echo.041 - Diskpart
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Diskpart.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k diskpart /?" /d:"Permite la configuraci�n del almacenamiento desde una secuencia de comandos, una sesi�n remota o el s�mbolo del sistema"

echo ----------------------------------------------------------------------

echo.042 - Diskperf
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Diskperf.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k diskperf /?" /d:"Utilidad que monitorea el rendimiento de un sistema local o remoto"

echo ----------------------------------------------------------------------

echo.043 - Dnslookup
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Dnslookup.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k dnslookup /?" /d:"Utilitario para preguntar el Domain Name System (DNS), incluyendo la IP de una computadora en particular"

echo ----------------------------------------------------------------------

echo.044 - Doskey
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Doskey.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k doskey /?" /d:"Edita l�neas de comandos, recupera comandos de Windows XP y crea macros"

echo ----------------------------------------------------------------------

echo.045 - Dosx
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Dosx.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k dosx /?" /d:"Pasa el Int�rprete de Comandos a MS-DOS 16 bit"

echo ----------------------------------------------------------------------

echo.046 - Driverquery
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Driverquery.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k driverquery /?" /d:"Permite al administrador enumerar y mostrar la lista de controladores de dispositivos instalados as� como sus propiedades"

echo ----------------------------------------------------------------------

echo.047 - Echo
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Echo.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k echo /?" /d:"Muestra mensajes o activa y desactiva el eco del comando"

echo ----------------------------------------------------------------------

echo.048 - Edit
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Edit.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k edit /?" /d:"Editor de MS-DOS"

echo ----------------------------------------------------------------------

echo.049 - Edlin
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Edlin.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k edlin /?" /d:"Editor de texto de l�neas"

echo ----------------------------------------------------------------------

echo.050 - Endlocal
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Endlocal.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k endlocal /?" /d:"Termina la secci�n de cambios locales de entorno en un archivo por lotes"

echo ----------------------------------------------------------------------

echo.051 - Erase
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Erase.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k erase /?" /d:"Elimina uno o m�s archivos"

echo ----------------------------------------------------------------------

echo.052 - Esentutl
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Esentutl.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k esentutl /?" /d:"Utilitario de mantenimiento para las bases de datos de Microsoft Windows"

echo ----------------------------------------------------------------------

echo.053 - Eventcreate
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Eventcreate.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k eventcreate /?" /d:"Permite a un administrador crear un Id. y mensaje de suceso personalizados en el registro de sucesos especificado"

echo ----------------------------------------------------------------------

echo.054 - Eventtriggers
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Eventtriggers.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k eventtriggers /?" /d:"Habilita al administrador para mostrar y configurar el Desencadenador de Eventos en sistemas locales o remotos"

echo ----------------------------------------------------------------------

echo.055 - Evntcmd
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Evntcmd.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k evntcmd /?" /d:"Herramienta de configuraci�n del traductor de sucesos"

echo ----------------------------------------------------------------------

echo.056 - Exe2bin
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Exe2bin.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k exe2bin /?" /d:"Convierte archivos (.exe) a formato binario"

echo ----------------------------------------------------------------------

echo.057 - Exit
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Exit.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k exit /?" /d:"Abandona el programa cmd.exe (int�rprete de comandos) o el archivo de comandos por lotes actual"

echo ----------------------------------------------------------------------

echo.058 - Expand
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Expand.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k expand /?" /d:"Expande uno o m�s archivos comprimidos"

echo ----------------------------------------------------------------------

echo.059 - Extract16
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Extract16.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k extract /?" /d:"Utilidad de extracci�n de archivos (.cab) 16 bit"

echo ----------------------------------------------------------------------

echo.060 - Extrac32
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Extrac32.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k extrac32 /?" /d:"Utilidad de extracci�n de archivos (.cab) 32 bit"

echo ----------------------------------------------------------------------

echo.061 - Fastopen
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Fastopen.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k fastopen /?" /d:"Pasa el Int�rprete de Comandos a MS-DOS 16 bit"

echo ----------------------------------------------------------------------

echo.062 - Fc
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Fc.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k fc /?" /d:"Compara dos archivos o conjuntos de archivos y muestra las diferencias entre ellos"

echo ----------------------------------------------------------------------

echo.063 - Find
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Find.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k find /?" /d:"Busca una cadena de texto en uno o m�s archivos"

echo ----------------------------------------------------------------------

echo.064 - Findstr
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Findstr.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k findstr /?" /d:"Busca cadenas en los archivos"

echo ----------------------------------------------------------------------

echo.065 - Finger
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Finger.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k finger /?" /d:"Muestra informaci�n sobre un usuario o usuarios en una computadora remota"

echo ----------------------------------------------------------------------

echo.066 - Fltmc
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Fltmc.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k fltmc /?" /d:"Muestra, carga y descarga controladores de filtro certificados"

echo ----------------------------------------------------------------------

echo.067 - Fontview
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Fontview.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k fontview /?" /d:"Muestra un ejemplo de salida de una fuente en la pantalla"

echo ----------------------------------------------------------------------

echo.068 - For
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\For.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k for /?" /d:"Ejecuta el comando para cada uno de los archivos especificados en el conjunto de archivos"

echo ----------------------------------------------------------------------

echo.069 - Forcedos
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Forcedos.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k forcedos /?" /d:"Inicia el programa especificado en el subsistema MS-DOS. Este comando s�lo es necesario para los programas de MS-DOS no reconocidos por Windows XP"

echo ----------------------------------------------------------------------

echo.070 - Format
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Format.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k format /?" /d:"Formatea un disco para ser usado con Windows XP"

echo ----------------------------------------------------------------------

echo.071 - Fsutil
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Fsutil.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k fsutil /?" /d:"Realiza muchas tareas relacionadas al sistema FAT y NTFS, como la gesti�n de puntos de an�lisis, gesti�n de archivos dispersos, desmontar o extender un volumen"

echo ----------------------------------------------------------------------

echo.072 - Ftype
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Ftype.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ftype /?" /d:"Muestra o modifica los tipos de archivos usados en las asociaciones de extensiones de archivos"

echo ----------------------------------------------------------------------

echo.073 - Getmac
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Getmac.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k getmac /?" /d:"Muestra la direcci�n MAC de uno o m�s adaptadores de red en un sistema"

echo ----------------------------------------------------------------------

echo.074 - Goto
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Goto.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k goto /?" /d:"Dirige cmd.exe a una l�nea con etiqueta en un programa por lotes"

echo ----------------------------------------------------------------------

echo.075 - Gpresult
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Gpresult.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k gpresult /?" /d:"Muestra el conjunto resultante de directivas (RSoP) para un usuario de destino y equipo"

echo ----------------------------------------------------------------------

echo.076 - Gpupdate
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Gpupdate.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k gpupdate /?" /d:"Actualiza la configuraci�n de las Directivas de Grupo"

echo ----------------------------------------------------------------------

echo.077 - Graftabl
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Graftabl.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k graftabl /?" /d:"Permite que Windows muestre caracteres extendidos en modo gr�fico"

echo ----------------------------------------------------------------------

echo.078 - Graphics
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Graphics.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k graphics /?" /d:"Carga un programa que puede imprimir im�genes gr�ficas"

echo ----------------------------------------------------------------------

echo.079 - Help
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Help.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k help /?" /d:"Proporciona informaci�n de ayuda para los comandos de Windows XP"

echo ----------------------------------------------------------------------

echo.080 - Hostname
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Hostname.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k hostname /?" /d:"Muestra el nombre del equipo (host)"

echo ----------------------------------------------------------------------

echo.081 - If
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\If.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k if /?" /d:"Realiza el procesamiento condicional de los programas por lotes"

echo ----------------------------------------------------------------------

echo.082 - Iisreset
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Iisreset.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k iisreset /?" /d:"Herramienta de l�nea de comandos para el control de IIS"

echo ----------------------------------------------------------------------

echo.083 - Ipconfig
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Ipconfig.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ipconfig /?" /d:"Permite obtener informaci�n de la direcci�n IP de un equipo de Windows. Tambi�n permite cierto control sobre conexiones activas TCP-IP"

echo ----------------------------------------------------------------------

echo.084 - Ipsec6
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Ipsec6.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ipsec6 /?" /d:"Manipula directivas y asociaciones de seguridad Psec IPv6"

echo ----------------------------------------------------------------------

echo.085 - Ipseccmd
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Ipseccmd.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ipseccmd /?" /d:"Configura el Internet Protocol Security (IPSec) en un servicio de directorio o en un registro local o remoto"

echo ----------------------------------------------------------------------

echo.086 - Ipv6
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Ipv6.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ipv6 /?" /d:"Herramienta para instalar y configurar IPv6"

echo ----------------------------------------------------------------------

echo.087 - Ipxroute
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Ipxroute.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ipxroute /?" /d:"Programa de control de enrutamiento IPX NWLink y de origen"

echo ----------------------------------------------------------------------

echo.088 - KB16
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\KB16.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k kb16 /?" /d:"Configura un teclado para un idioma espec�fico"

echo ----------------------------------------------------------------------

echo.089 - Label
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Label.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k label /?" /d:"Crea, cambia o elimina la etiqueta de volumen de un disco"

echo ----------------------------------------------------------------------

echo.090 - Loadfix
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Loadfix.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k loadfix /?" /d:"Carga un programa por encima de los 64K de memoria y lo ejecuta"

echo ----------------------------------------------------------------------

echo.091 - Locator
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Locator.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k locator /?" /d:"Localizador Remote Procedure Call (RPC)"

echo ----------------------------------------------------------------------

echo.092 - Lodctr
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Lodctr.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k lodctr /?" /d:"Actualiza el nombre de los contadores del Monitor del sistema y da texto explicativo para un contador extensible"

echo ----------------------------------------------------------------------

echo.093 - Logman
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Logman.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k logman /?" /d:"Administra el servicio de Registros y Alertas de Rendimiento para crear y controlar los registros de sesi�n de seguimiento de sucesos y registros de rendimiento"

echo ----------------------------------------------------------------------

echo.094 - Logoff
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Logoff.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k logoff /?" /d:"Termina una sesi�n"

echo ----------------------------------------------------------------------

echo.095- Lpq
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Lpq.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k lpq /?" /d:"Muestra el estado de una cola Line Printer Daemon (LPD) remota"

echo ----------------------------------------------------------------------

echo.096 - Lpr
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Lpr.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k lpr /?" /d:"Env�a un trabajo de impresi�n a una impresora de red"

echo ----------------------------------------------------------------------

echo.097 - Makecab
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Makecab.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k makecab /?" /d:"Es una utilidad que permite tomar los archivos existentes y empaquetarlos en un archivo contenedor (.cab)"

echo ----------------------------------------------------------------------

echo.098 - Md
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Md.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k md /?" /d:"Crea un directorio"

echo ----------------------------------------------------------------------

echo.099 - Mem
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Mem.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k mem /?" /d:"Muestra la cantidad de memoria usada y libre en el sistema"

echo ----------------------------------------------------------------------

echo.100 - Mkdir
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Mkdir.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k mkdir /?" /d:"Crea un directorio"

echo ----------------------------------------------------------------------

echo.101 - Mode
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Mode.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k mode /?" /d:"Configura los dispositivos de sistema"

echo ----------------------------------------------------------------------

echo.102 - Mofcomp
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Mofcomp.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k mofcomp /?" /d:"Herramienta de l�nea para cargar el c�digo de MOF en el repositorio de WMI"

echo ----------------------------------------------------------------------

echo.103 - More
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\More.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k more /?" /d:"Muestra la informaci�n pantalla a pantalla"

echo ----------------------------------------------------------------------

echo.104 - Mountvol
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Mountvol.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k mountvol /?" /d:"Crea, suprime o lista un punto de montaje de volumen"

echo ----------------------------------------------------------------------

echo.105 - Move
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Move.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k move /?" /d:"Mueve archivos y cambia el nombre a archivos y directorios"

echo ----------------------------------------------------------------------

echo.106 - Mqbkup
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Mqbkup.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k mqbkup /?" /d:"Utilidad de copia de seguridad y restauraci�n de Microsoft Message Queue Server (MSMQ)"

echo ----------------------------------------------------------------------

echo.107 - Mqsvc
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Mqsvc.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k mqsvc /?" /d:"Este servicio implementa la infraestructura de comunicaciones para Microsoft Message Queue Server (MSMQ)"

echo ----------------------------------------------------------------------

echo.108 - Mqtgsvc
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Mqtgsvc.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k mqtgsvc /?" /d:"Servicio disparador de Microsoft Message Queue Server (MSMQ)"

echo ----------------------------------------------------------------------

echo.109 - Mrinfo
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Mrinfo.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k mrinfo /?" /d:"Sirve para consultar un enrutador multidifusi�n y obtener informaci�n sobre sus interfaces y vecinos"

echo ----------------------------------------------------------------------

echo.110 - Msg
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Msg.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k msg /?" /d:"Enviar un mensaje a un usuario"

echo ----------------------------------------------------------------------

echo.111 - Msiexec
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Msiexec.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k msiexec /?" /d:"Instalador de Windows. Se usa para crear paquetes de instalaci�n para aplicaciones y programas"

echo ----------------------------------------------------------------------

echo.112 - Nbtstat
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Nbtstat.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k nbtstat /?" /d:"Muestra las estad�sticas del protocolo y las conexiones actuales de TCP-IP usando NBT (NetBIOS sobre TCP-IP)"

echo ----------------------------------------------------------------------

echo.113 - Net
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Net.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k net /?" /d:"Se utiliza para actualizar, corregir o ver la red o la configuraci�n de la red"

echo ----------------------------------------------------------------------

echo.114 - Net1
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Net1.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k net1 /?" /d:"Se utiliza para administrar, configurar y ver los controles relacionados con la red, tales como uso de red, usuario de impresi�n y usuario de red"

echo ----------------------------------------------------------------------

echo.115 - Netsh
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Netsh.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k netsh /?" /d:"Permite, ya sea localmente o remotamente, mostrar o modificar la configuraci�n de red de un equipo que se est� ejecutando actualmente"

echo ----------------------------------------------------------------------

echo.116 - Netstat
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Netstat.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k netstat /?" /d:"Muestra estad�sticas del protocolo y conexiones TCP-IP actuales"

echo ----------------------------------------------------------------------

echo.117 - Nlsfunc
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Nlsfunc.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k nlsfunc /?" /d:"Carga informaci�n espec�fica de un pa�s por National Language Support (NLS)"

echo ----------------------------------------------------------------------

echo.118 - Ntsd
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Ntsd.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ntsd /?" /d:"Utilitario depurador de errores de programas Microsoft NT Symbolic Debugger (NTSD)"

echo ----------------------------------------------------------------------

echo.119 - Ntvdm
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Ntvdm.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ntvdm /?" /d:"Proporciona la MS-DOS Virtual Machine (VDM) utilizada para alojar aplicaciones 16 bit de DOS y Windows"

echo ----------------------------------------------------------------------

echo.120 - Nw16
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Nw16.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k nw16 /?" /d:"Redirector de NetWare VDM"

echo ----------------------------------------------------------------------

echo.121 - Nwscript
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Nwscript.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k nwscript /?" /d:"Utilidad para proporcionar inicio de sesi�n en un servidor NetWare desde una PC con Windows"

echo ----------------------------------------------------------------------

echo.122 - Odbcconf
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Odbcconf.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k odbcconf /?" /d:"Permite configurar nombres de origen de datos y los controladores ODBC" 

echo ----------------------------------------------------------------------

echo.123 - Openfiles
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Openfiles.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k openfiles /?" /d:"Permite a un administrador listar o desconectar archivos o carpetas que se abrieron en un sistema" 

echo ----------------------------------------------------------------------

echo.124 - Osuninst
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Osuninst.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k osuninst /?" /d:"Utilitario para desinstalar Windows XP y volver a un sistema operativo anterior"

echo ----------------------------------------------------------------------

echo.125 - Path
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Path.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k path /?" /d:"Muestra o establece una ruta de b�squeda para archivos ejecutables"

echo ----------------------------------------------------------------------

echo.126 - Pathping
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Pathping.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k pathping /?" /d:"Proporciona informaci�n sobre la ruta que lleva los datos a su destino, la latencia y la p�rdida de la red en saltos intermedios entre un or�gen y un destino"

echo ----------------------------------------------------------------------

echo.127 - Pause
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Pause.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k pause /?" /d:"Suspende el proceso de un programa por lotes y muestra el mensaje"

echo ----------------------------------------------------------------------

echo.128 - Pentnt
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Pentnt.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k pentnt /?" /d:"Reporta si la computadora local exhibe el error de Divisi�n de Punto Flotante de los procesadores Intel Pentium"

echo ----------------------------------------------------------------------

echo.129 - Ping
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Ping.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ping /?" /d:"Env�a un paquete a un host de Internet o a un equipo de la red y mide el tiempo de respuesta"

echo ----------------------------------------------------------------------

echo.130 - Ping6
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Ping6.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ping6 /?" /d:"Es una utilidad TCP-IP para comprobar la disponibilidad IPv6 de un determinado host o equipo de red"	

echo ----------------------------------------------------------------------

echo.131 - Popd
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Popd.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k popd /?" /d:"Cambia al directorio guardado por el comando PUSHD"

echo ----------------------------------------------------------------------

echo.132 - Powercfg
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Powercfg.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k powercfg /?" /d:"Herramienta que permite al administrador controlar las opciones de energ�a del sistema" 

echo ----------------------------------------------------------------------

echo.133 - Print
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Print.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k print /?" /d:"Imprime un archivo de texto"

echo ----------------------------------------------------------------------

echo.134 - Prompt
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Prompt.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k prompt /?" /d:"Cambia el s�mbolo del sistema de cmd.exe"

echo ----------------------------------------------------------------------

echo.135 - Proxycfg
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Proxycfg.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k proxycfg /?" /d:"Herramienta predeterminada de configuraci�n del proxy WinHTTP de Microsoft"

echo ----------------------------------------------------------------------

echo.136 - Pushd
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Pushd.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k pushd /?" /d:"Guarda el directorio actual para que lo use el comando POPD y despu�s cambia al directorio especificado"

echo ----------------------------------------------------------------------

echo.137 - Qappsrv
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Qappsrv.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k qappsrv /?" /d:"Muestra los Servidores de Terminal de aplicaci�n disponibles en la red"

echo ----------------------------------------------------------------------

echo.138 - Qprocess
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Qprocess.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k qprocess /?" /d:"Muestra informaci�n sobre procesos"

echo ----------------------------------------------------------------------

echo.139 - Qwinsta
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Qwinsta.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k qwinsta /?" /d:"Muestra informaci�n sobre Sesiones de Terminal"

echo ----------------------------------------------------------------------

echo.140 - Rasautou
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Rasautou.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k rasautou /?" /d:"Utilitario que permite conexiones remotas de acceso telef�nico entre las PC"

echo ----------------------------------------------------------------------

echo.141 - Rasdial
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Rasdial.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k rasdial /?" /d:"Proporciona marcado desatendido por RAS-PPPOE" 

echo ----------------------------------------------------------------------

echo.142 - Rcp
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Rcp.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k rcp /?" /d:"Copia archivos a y desde equipos con el servicio RCP en funcionamiento" 

echo ----------------------------------------------------------------------

echo.143 - Rd
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Rd.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k rd /?" /d:"Quita un directorio"

echo ----------------------------------------------------------------------

echo.144- Recover
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Recover.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k recover /?" /d:"Recupera la informaci�n legible de un disco da�ado o defectuoso"

echo ----------------------------------------------------------------------

echo.145 - Redir
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Redir.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k redir /?" /d:"Es un redirector de puerto VDM, que sirve para reenviar conexiones entrantes a otro lugar"

echo ----------------------------------------------------------------------

echo.146 - Reg
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Reg.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k reg /?" /d:"Herramienta de registro de consola para Windows"

echo ----------------------------------------------------------------------

echo.147 - Regsvr32
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Regsvr32.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k regsvr32 /?" /d:"Herramienta para registrar y anular el registro de controles OLE, como los archivos DLL o controles ActiveX (OCX)"

echo ----------------------------------------------------------------------

echo.148 - Regwiz
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Regwiz.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k regwiz /?" /d:"Asistente de registro"

echo ----------------------------------------------------------------------

echo.149 - Relog
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Relog.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k relog /?" /d:"Crea nuevos registros de rendimiento a partir de datos de registros de rendimiento existentes cambiando el intervalo de muestreo o convirtiendo el formato del archivo"

echo ----------------------------------------------------------------------

echo.150 - Rem
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Rem.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k rem /?" /d:"Registra los comentarios en un archivo por lotes o en CONFIG.SYS"

echo ----------------------------------------------------------------------

echo.151 - Ren
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Ren.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ren /?" /d:"Cambia el nombre de uno o m�s archivos"

echo ----------------------------------------------------------------------

echo.152 - Rename
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Rename.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k rename /?" /d:"Cambia el nombre de uno o m�s archivos"

echo ----------------------------------------------------------------------

echo.153 - Replace
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Replace.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k replace /?" /d:"Reemplaza archivos"

echo ----------------------------------------------------------------------

echo.154 - Reset
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Reset.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k reset /?" /d:"Restablece un servicio"

echo ----------------------------------------------------------------------

echo.155 - Rexec
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Rexec.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k rexec /?" /d:"Ejecuta comandos en host remotos que ejecutan el servicio REXEC" 

echo ----------------------------------------------------------------------

echo.156 - Rmdir
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Rmdir.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k rmdir /?" /d:"Quita un directorio" 

echo ----------------------------------------------------------------------

echo.157 - Robocopy
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Robocopy.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k robocopy /?" /d:"Herramienta para copia eficaz de archivos (Robust File Copy)"

echo ----------------------------------------------------------------------

echo.158 - Route
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Route.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k route /?" /d:"Manipula tablas de enrutamiento de red"

echo ----------------------------------------------------------------------

echo.159 - Rsh
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Rsh.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k rsh /?" /d:"Ejecuta comandos en host remotos que est�n ejecutando el servicio RSH" 

echo ----------------------------------------------------------------------

echo.160 - Rsm
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Rsm.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k rsm /?" /d:"Administra los recursos utilizando medios de almacenamiento extra�bles. Puede ejecutar secuencias de comandos por lotes para aplicaciones que no soportan la API de almacenamiento extra�ble"

echo ----------------------------------------------------------------------

echo.161 - Runas
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Runas.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k runas /?" /d:"Permite a un usuario ejecutar herramientas y programas espec�ficos con diferentes permisos que el actual usuario"

echo ----------------------------------------------------------------------

echo.162 - Rwinsta
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Rwinsta.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k rwinsta /?" /d:"Volver a establecer el hardware y el software de subsistema de la sesi�n con los valores inciales conocidos"

echo ----------------------------------------------------------------------

echo.163 - Sc
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Sc.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k sc /?" /d:"Usado para comunicarse con el Controlador de Servicio NT y los servicios"

echo ----------------------------------------------------------------------

echo.164 - Scardsvr 
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Scardsvr .lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k scardsvr /?" /d:"Tarjeta Inteligente de Gesti�n de Recursos para Server"

echo ----------------------------------------------------------------------

echo.165 - Schtasks
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Schtasks.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k schtasks /?" /d:"Habilita a un administrador a crear, eliminar, consultar, cambiar, ejecutar y terminar tareas programadas en un sistema local o remoto. Reemplaza a at.exe"

echo ----------------------------------------------------------------------

echo.166 - Sdbinst
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Sdbinst.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k sdbinst /?" /d:"Utilizado por el administrador para crear una base de datos de Correcciones de Compatibilidad (shims) a las aplicaciones que no se ejecutan correctamente de forma predeterminada"

echo ----------------------------------------------------------------------

echo.167 - Secedit
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Secedit.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k secedit /?" /d:"Configura y analiza la seguridad del sistema mediante la comparaci�n de la configuraci�n actual con al menos una plantilla"

echo ----------------------------------------------------------------------

echo.168 - Set
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Set.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k set /?" /d:"Muestra. establece o quita las variables de entorno de cmd.exe"

echo ----------------------------------------------------------------------

echo.169 - Setlocal
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Setlocal.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k setlocal /?" /d:"Comienza la secci�n de cambios locales de entorno en un archivo por lotes"

echo ----------------------------------------------------------------------

echo.170 - Setver
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Setver.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k setver /?" /d:"Establece el n�mero de versi�n que MS-DOS indica a los programas"

echo ----------------------------------------------------------------------

echo.171 - Sfc
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Sfc.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k sfc /?" /d:"Busca archivos de sistema protegidos y reemplaza las versiones incorrectas por las correctas"

echo ----------------------------------------------------------------------

echo.172 - Shadow
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Shadow.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k shadow /?" /d:"Monitorizar otra sesi�n de Servicios de Terminal"

echo ----------------------------------------------------------------------

echo.173 - Shift
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Shift.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k shift /?" /d:"Cambia la posici�n de par�metros reemplazables en un archivo por lotes"

echo ----------------------------------------------------------------------

echo.174 - Shutdown
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Shutdown.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k shutdown /?" /d:"Apaga el equipo, pero tambi�n ofrece par�metros para cerrar la sesi�n de un usuario, reiniciar el equipo y anular un apagado del sistema"

echo ----------------------------------------------------------------------

echo.175 - Sort
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Sort.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k sort /?" /d:"Lee la entrada, clasifica los datos y escribe los resultados en la pantalla, a un archivo, o a otro dispositivo"

echo ----------------------------------------------------------------------

echo.176 - Start
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Start.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k start /?" /d:"Inicia una ventana aparte para ejecutar un programa o un comando especificado"

echo ----------------------------------------------------------------------

echo.177 - Subst
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Subst.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k subst /?" /d:"Asocia una ruta de acceso con una letra de unidad"

echo ----------------------------------------------------------------------

echo.178 - Sysocmgr
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Sysocmgr.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k sysocmgr /?" /d:"Administrador de componentes opcionales"

echo ----------------------------------------------------------------------

echo.179 - Systeminfo
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Systeminfo.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k systeminfo /?" /d:"Permite al administrador buscar informaci�n b�sica de configuraci�n del sistema"

echo ----------------------------------------------------------------------

echo.180 - Taskkill
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Taskkill.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k taskkill /?" /d:"Esta herramienta se usa para terminar procesos a trav�s del Id. de proceso (PID) o del nombre de imagen"

echo ----------------------------------------------------------------------

echo.181 - Tasklist
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Tasklist.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tasklist /?" /d:"Muestra una lista de aplicaciones y las tareas o procesos asociados que se ejecutan en un sistema local o remoto"

echo ----------------------------------------------------------------------

echo.182 - Tcmsetup
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Tcmsetup.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tcmsetup /?" /d:"Configura o deshabilita al cliente de telefon�a TAPI"

echo ----------------------------------------------------------------------

echo.183 - Tftp
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Tftp.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tftp /?" /d:"Transfiere los archivos a y desde un equipo remoto con el servicio TFTP en funcionamiento" 

echo ----------------------------------------------------------------------

echo.184 - Time
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Time.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k time /?" /d:"Muestra o establece la hora del sistema"

echo ----------------------------------------------------------------------

echo.185 - Title
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Title.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k title /?" /d:"Fija el t�tulo de la ventana en la ventana del s�mbolo del sistema"

echo ----------------------------------------------------------------------

echo.186 - Tlntadmn
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Tlntadmn.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tlntadmn /?" /d:"Se utiliza para administrar un equipo local o remoto que ejecuta el servidor Telnet"

echo ----------------------------------------------------------------------

echo.187 - Tlntsess
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Tlntsess.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tlntsess /?" /d:"Muestra la sesi�nes a las cuales est� conectado Telnet"  

echo ----------------------------------------------------------------------

echo.188 - Tracerpt
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Tracerpt.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tracerpt /?" /d:"Procesa los registros o datos en tiempo real de los proveedores de seguimiento de eventos y permite generar informes de an�lisis de seguimiento y archivos CSV (delimitado por comas) para los sucesos generados"

echo ----------------------------------------------------------------------

echo.189 - Tracert
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Tracert.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tracert /?" /d:"Determina la ruta tomada hacia un destino mediante el env�o de mensajes de solicitud de eco Internet Control Message Protocol (ICMP)"

echo ----------------------------------------------------------------------

echo.190 - Tracert6
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Tracert6.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tracert6 /?" /d:"Determina la ruta tomada por los paquetes IPv6 desde este equipo a otro equipo remoto"

echo ----------------------------------------------------------------------

echo.191 - Tree
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Tree.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tree /?" /d:"Muestra de forma gr�fica la estructura de carpetas de una unidad o ruta"

echo ----------------------------------------------------------------------

echo.192 - Tscon
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Tscon.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tscon /?" /d:"Adjunta una sesi�n de usuario a una sesi�n de Terminal"

echo ----------------------------------------------------------------------

echo.193 - Tscupgrd
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Tscupgrd.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tscupgrd /?" /d:"Este servicio actualiza el arranque de Servicios de Terminal Server en la pr�xima actualizaci�n de Windows"

echo ----------------------------------------------------------------------

echo.194 - Tsdiscon
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Tsdiscon.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tsdiscon /?" /d:"Desconecta una sesi�n de Terminal (Escritorio remoto)"

echo ----------------------------------------------------------------------

echo.195 - Tskill
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Tskill.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tskill /?" /d:"Termina un proceso"

echo ----------------------------------------------------------------------

echo.196 - Tsshutdn
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Tsshutdn.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tsshutdn /?" /d:"Apague un servidor de manera controlada"

echo ----------------------------------------------------------------------

echo.197 - Type
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Type.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k type /?" /d:"Muestra el contenido de uno o m�s archivos de texto"

echo ----------------------------------------------------------------------

echo.198 - Typeperf
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Typeperf.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k typeperf /?" /d:"Escribe la informaci�n de rendimiento en la ventana de comandos o en un archivo de registro"

echo ----------------------------------------------------------------------

echo.199 - Tzchange
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Tzchange.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tzchange /?" /d:"Utilidad para hacer cambios en los husos horarios"

echo ----------------------------------------------------------------------

echo.200 - Unlodctr
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Unlodctr.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k unlodctr /?" /d:"Quita el nombre de contador y texto explicativo para el contador extensible especificado"

echo ----------------------------------------------------------------------

echo.201 - Userinit
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Userinit.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k userinit /?" /d:"Especifica los programas que Winlogon ejecuta cuando un usuario se conecta"

echo ----------------------------------------------------------------------

echo.202 - Ver
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Ver.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ver /?" /d:"Muestra la versi�n de Windows XP"

echo ----------------------------------------------------------------------

echo.203 - Verify
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Verify.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k verify /?" /d:"Especifica si cmd.exe debe comprobar que los archivos se escriban de forma correcta en un disco"

echo ----------------------------------------------------------------------

echo.204 - Vol
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Vol.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k vol /?" /d:"Muestra la etiqueta del volumen del disco y el n�mero de serie, si existen"

echo ----------------------------------------------------------------------

echo.205 - Vssadmin
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Vssadmin.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k vssadmin /?" /d:"Herramienta administrativa del Servicio de instant�nea de volumen"

echo ----------------------------------------------------------------------

echo.206 - Vwipxspx
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Vwipxspx.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k vwipxspx /?" /d:"Un componente redirector de NetWare"

echo ----------------------------------------------------------------------

echo.207 - W32tm
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\W32tm.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k w32tm /?" /d:"Se utiliza para configurar los ajustes de servicio de hora de Windows y tambi�n puede utilizarse para diagnosticar problemas con el servicio de hora"

echo ----------------------------------------------------------------------

echo.208 - Wmic
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Wmic.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k wmic /?" /d:"Windows Management Instrumentation Command-line (WMIC) es una l�nea de comandos e interfaz de secuencias de comandos que simplifica el uso y los sistemas administrados a trav�s de WMI"

echo ----------------------------------------------------------------------

echo.209 - Wupdmgr
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Wupdmgr.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k wupdmgr /?" /d:"Lleva a Microsoft Windows Update"

echo ----------------------------------------------------------------------

echo.210 - Xcopy
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\L�nea de Comandos XP\Xcopy.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k xcopy /?" /d:"Copia �rboles de archivos y directorios"

echo ----------------------------------------------------------------------
echo.
echo                         Instalaci�n finalizada
echo.
echo ----------------------------------------------------------------------
echo.

pause

exit