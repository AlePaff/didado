cls

::Instalador de atajos de programas que no son instalados por defecto por Windows XP (Home o Professional)
::Sirve solamente para Windows XP Service Pack 3 en su instalaci�n completa
::� 2010 - � DI-DA-DO Computaci�n
::Buenos Aires, Argentina
::didadocom@yahoo.com
::30/07/2010

@echo off

color 47

title Aplicaciones Ocultas de Windows XP

echo.
echo ------------------------ DI-DA-DO Computaci�n ------------------------
echo.
echo.                Instalador de Aplicaciones Ocultas XP
echo.
echo ----------------------------------------------------------------------

If Not Exist "%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP" (Md "%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP")

::Windows Version 
echo.01 - Acerca de Windows
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Acerca de Windows.lnk" /a:c /t:"%SYSTEMROOT%\system32\winver.exe" /d:"Informa la versi�n de Microsoft Windows XP"

echo ----------------------------------------------------------------------

::Disk Management 
echo.02 - Administraci�n de discos
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Administraci�n de discos.lnk" /a:c /t:"%SYSTEMROOT%\system32\diskmgmt.msc" /d:"Consola de administraci�n de medios de almacenamiento"

echo ----------------------------------------------------------------------

::Front Page Extensions Manager
echo.03 - Administrador de extensiones de servidor de FrontPage
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Administrador de extensiones de servidor de FrontPage.lnk" /a:c /t:"C:\Archivos de programa\Archivos comunes\Microsoft Shared\web server extensions\40\bin\fpmmc.msc" /d:"Programa de servidor que permite que el software cliente de Microsoft FrontPage interact�e con las extensiones para las actualizaciones de contenido y autor�a"

echo ----------------------------------------------------------------------

::Legacy Program Manager (Windows 3.x, Windows for Workgroups, and Windows NT 3.51)
echo.04 - Administrador de programas de Windows 3.x
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Administrador de programas Windows 3.x.lnk" /a:c /t:"%SYSTEMROOT%\system32\progman.exe" /d:"Programa de administraci�n para Windows 3.x, Windows para Grupos de Trabajo y Windows NT 3.51. Funciona solo con Service Pack 1"

echo ----------------------------------------------------------------------

::Windows NT NetDDE Share Manager
echo.05 - Administrador de recursos compartidos DDE
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Administrador de recursos compartidos DDE.lnk" /a:c /t:"%SYSTEMROOT%\system32\ddeshare.exe" /d:"Puede utilizar Recursos Compartidos DDE para administrar c�mo se comunican los programas y c�mo comparten datos en una red mediante la creaci�n, modificaci�n y eliminaci�n de recursos compartidos de Intercambio Din�mico de Datos (DDE)"

echo ----------------------------------------------------------------------

::Task Manager 
echo.06 - Administrador de tareas de Windows
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Administrador de tareas de Windows.lnk" /a:c /t:"%SYSTEMROOT%\system32\taskmgr.exe" /d:"Proporciona informaci�n acerca de los programas y procesos que se est�n ejecutando en el equipo"

echo ----------------------------------------------------------------------

::Driver Verifier Manager
echo.07 - Administrador del comprobador de controlador
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Administrador del comprobador de controlador.lnk" /a:c /t:"%SYSTEMROOT%\system32\verifier.exe" /d:"Herramienta para solucionar problemas de los controladores"

echo ----------------------------------------------------------------------

::Accounts Database Encryption
echo.08 - Asegurar la base de datos de cuentas de Windows
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Asegurar la base de datos de cuentas de Windows.lnk" /a:c /t:"%SYSTEMROOT%\system32\syskey.exe" /d:"Permite configurar la base de datos de cuentas para permitir cifrado adicional (bloqueo de SAM), con lo que tendr� protecci�n extra ante cualquier intromisi�n en la base de datos"

echo ----------------------------------------------------------------------

::Network Sharing Wizard
echo.09 - Asistente para crear una carpeta compartida
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Asistente para crear una carpeta compartida.lnk" /a:c /t:"%SYSTEMROOT%\system32\shrpubw.exe" /d:"Ofrece procedimientos paso a paso para que una carpeta especificada pueda tener acceso a otros usuarios y computadoras en la red"

echo ----------------------------------------------------------------------

::Scanner and Camera Wizard
echo.10 - Asistente para esc�neres y c�maras
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Asistente para esc�neres y c�maras.lnk" /a:c /t:"%SYSTEMROOT%\system32\wiaacmgr.exe" /d:"Este asistente se utiliza en la adquisici�n de im�genes desde esc�neres y c�maras digitales"

echo ----------------------------------------------------------------------

::BlueTooth File Transfer Wizard
echo.11 - Asistente para la transferencia de archivos Bluetooth
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Asistente para la transferencia de archivos Bluetooth.lnk" /a:c /t:"%SYSTEMROOT%\system32\fsquirt.exe" /d:"Si Windows no reconoce un dispositivo Bluetooth, podr� utilizarlo mediante la compatibilidad de software gen�rica que incluye Windows, o puede utilizar el controlador suministrado por el fabricante del dispositivo"

echo ----------------------------------------------------------------------

::Windows Help 16
echo.12 - Ayuda de Windows 16 bit
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Ayuda de Windows 16 bit.lnk" /a:c /t:"%SYSTEMROOT%\winhelp.exe" /d:"El programa de Ayuda de Windows es una utilidad de Windows necesaria cuando se est� utilizando software antiguo de 16 bit que contiene archivos de ayuda (.hlp)"

echo ----------------------------------------------------------------------

::Windows Help 32
echo.13 - Ayuda de Windows 32 bit
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Ayuda de Windows 32 bit.lnk" /a:c /t:"%SYSTEMROOT%\winhlp32.exe" /d:"El programa de Ayuda de Windows es una utilidad de Windows necesaria cuando se est� utilizando software antiguo de 32 bit que contiene archivos de ayuda (.hlp)"

echo ----------------------------------------------------------------------

::Shared Folder Manager
echo.14 - Carpetas compartidas
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Carpetas compartidas.lnk" /a:c /t:"%SYSTEMROOT%\system32\fsmgmt.msc" /d:"Muestra carpetas compartidas, sesiones actuales y archivos abiertos"

echo ----------------------------------------------------------------------

::Certificates 
echo.15 - Certificados
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Certificados.lnk" /a:c /t:"%SYSTEMROOT%\system32\certmgr.msc" /d:"El complemento de certificados le permite examinar el contenido de los almacenes de certificados, un servicio o un equipo"

echo ----------------------------------------------------------------------

::Windows Network Chat 
echo.16 - Charla
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Charla.lnk" /a:c /t:"%SYSTEMROOT%\system32\winchat.exe" /d:"Puede utilizar Charla de Windows para Trabajo en Grupo (NT) en su equipo para comunicarse con alguien que est� en otro equipo. Los dos equipos tienen que estar conectados a la misma red y deben ejecutar un protocolo similar"

echo ----------------------------------------------------------------------

::Telnet Client 
echo.17 - Cliente Telnet
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Cliente Telnet.lnk" /a:c /t:"%SYSTEMROOT%\system32\telnet.exe" /d:"Con el cliente Telnet, los usuarios de Windows se pueden conectar con un equipo remoto que ejecute un servidor Telnet y ejecutar aplicaciones o realizar tareas administrativas en el equipo remoto"

echo ----------------------------------------------------------------------

::Signature Verification Tool 
echo.18 - Comprobaci�n de la firma del archivo
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Comprobaci�n de la firma del archivo.lnk" /a:c /t:"%SYSTEMROOT%\system32\sigverif.exe" /d:"Cuando los desarrolladores de Microsoft y los vendedores de terceras partes crean un nuevo controlador, este es sometido a un departamento especial para su firma. No todos los vendedores hacen esto y puede resultar en problemas en la estabilidad del equipo"

echo ----------------------------------------------------------------------

::Windows Management Instrumentation Test Tool
echo.19 - Comprobaci�n del instrumental de administraci�n de Windows
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Comprobaci�n del instrumental de administraci�n de Windows.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\wbemtest.exe" /d:"Es un programa de utilizaci�n general para ver o modificar clases, instancias o m�todos del Modelo de Informaci�n Com�n (CIM) durante el desarrollo de proveedores de Instrumentaci�n de Administraci�n de Windows (WMI) y sus aplicaciones"

echo ----------------------------------------------------------------------

::Windows Script Host
echo.20 - Configuraci�n de Microsoft Script Host
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Configuraci�n de Microsoft Script Host.lnk" /a:c /t:"%SYSTEMROOT%\system32\wscript.exe" /d:"Permite que se ejecuten secuencias de comandos en un archivo de secuencia de comandos o escribiendo el nombre de un archivo de comandos en el s�mbolo del sistema. Tambien act�a para comandos ActiveX, VBScript y JavaScript"

echo ----------------------------------------------------------------------

::Windows Local Security Settings
echo.21 - Configuraci�n de seguridad local
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Configuraci�n de seguridad local.lnk" /a:c /t:"%SYSTEMROOT%\system32\secpol.msc" /d:"Extiende el complemento de Directiva de Grupo y le ayuda a definir directivas de seguridad local para los equipos de su dominio"

echo ----------------------------------------------------------------------

::Event Translator Config Tool
echo.22 - Configuraci�n del traductor de sucesos a captura
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Configuraci�n del traductor de sucesos a captura.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\evntwin.exe" /d:"Permite a los usuarios supervisar los sucesos registrados en los registros de aplicaci�n, de seguridad y del sistema"

echo ----------------------------------------------------------------------

::Resultant Set of Policy
echo.23 - Conjunto resultante de directivas
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Conjunto resultante de directivas.lnk" /a:c /t:"%SYSTEMROOT%\system32\rsop.msc" /d:"Es un complemento de Directiva de Grupo que simplifica la implementaci�n y la soluci�n de problemas de directivas"

echo ----------------------------------------------------------------------

::Group Convert
echo.24 - Conversor de grupos para el Administrador de programas de Windows
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Conversor de grupos para el Administrador de programas.lnk" /a:c /t:"%SYSTEMROOT%\system32\grpconv.exe" /d:"Convierte Microsoft Windows 3.x y Microsoft Windows para Grupos de Trabajo en elementos del Men� Inicio"

echo ----------------------------------------------------------------------

::Create a Briefcase
echo.25 - Crea un Malet�n
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Crea un Malet�n.lnk" /a:c /t:"%SYSTEMROOT%\system32\syncapp.exe" /d:"Ayuda a mantener sus archivos actualizados al sincronizar autom�ticamente m�ltiples copias de archivos individuales en dos o m�s equipos"

echo ----------------------------------------------------------------------

::Network Diagnostic for Windows XP
echo.26 - Diagn�stico de red para Windows XP
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Diagn�stico de red para Windows XP.lnk" /a:c /t:"%SYSTEMROOT%\Network Diagnostic\xpnetdiag.exe" /d:"Identifica y corrige problemas de conexi�n que pueden producirse en equipos de una red dom�stica que se conecta a Internet mediante un m�dem por cable o mediante un m�dem de l�nea de suscriptor digital (ADSL)"

echo ----------------------------------------------------------------------

::Group Policy Object Editor
echo.27 - Directiva de grupo
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Directiva de grupo.lnk" /a:c /t:"%SYSTEMROOT%\system32\gpedit.msc" /d:"Este complemento le permite editar los objetos de Directiva de Grupo que pueden ser vinculados a un sitio, dominio o departamento en Active Directory o almacenados en un equipo en una carpeta oculta especial"

echo ----------------------------------------------------------------------

::Dr Watson diagnosis
echo.28 - Dr. Watson
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Dr. Watson.lnk" /a:c /t:"%SYSTEMROOT%\system32\drwatson.exe" /d:"Utilitario depurador de errores de programas"

echo ----------------------------------------------------------------------

::Dr Watson32 diagnosis for Windows
echo.29 - Dr. Watson32 para Windows
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Dr. Watson para Windows.lnk" /a:c /t:"%SYSTEMROOT%\system32\drwtsn32.exe" /d:"Utilitario depurador de errores de programas para Windows"

echo ----------------------------------------------------------------------

::Private Character Editor 
echo.30 - Editor de caracteres privados
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Editor de caracteres privados.lnk" /a:c /t:"%SYSTEMROOT%\system32\eudcedit.exe" /d:"Editor de caracteres privados con el cual se pueden crear hasta 6.400 caracteres exclusivos"

echo ----------------------------------------------------------------------

::System Configuration Editor 
echo.31 - Editor de configuraci�n de sistema
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Editor de configuraci�n de sistema.lnk" /a:c /t:"%SYSTEMROOT%\system32\sysedit.exe" /d:"Editor de texto de 16 bit en el cual se puede editar los archivos SYSTEM.INI, WIN.INI, CONFIG.SYS y AUTOEXEC.BAT"

echo ----------------------------------------------------------------------

::MS-DOS Editor
echo.32 - Editor de texto MS-DOS
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Editor de texto MS-DOS.lnk" /a:c /t:"%SYSTEMROOT%\system32\edit.com" /d:"Editor de texto MS-DOS"

echo ----------------------------------------------------------------------

::Registry Editor Utility
echo.33 - Editor del Registro
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Editor del Registro.lnk" /a:c /t:"%SYSTEMROOT%\system32\regedt32.exe" /d:"El editor de configuraci�n del Registro de Windows NT se usa para ver y modificar su base de datos. Si el Registro contiene valores incorrectos o faltan valores, puede ocasionar que la instalaci�n de Windows quede inutilizable"

echo ----------------------------------------------------------------------

::Object Packager 
echo.34 - Empaquetador de objetos  (Paquete)
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Empaquetador de objetos  (Paquete).lnk" /a:c /t:"%SYSTEMROOT%\system32\packager.exe" /d:"Herramienta que permite crear un paquete que se puede insertar en un archivo"

echo ----------------------------------------------------------------------

::SQL Server Client Network Utility
echo.35 - Herramienta de cliente de red de SQL Server
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Herramienta de cliente de red de SQL Server.lnk" /a:c /t:"%SYSTEMROOT%\system32\cliconfg.exe" /d:"Herramienta para configurar las conexiones de los clientes de la red a los servidores SQL"

echo ----------------------------------------------------------------------

::DirectX diagnosis 
echo.36 - Herramienta de diagn�stico de DirectX
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Herramienta de diagn�stico de DirectX.lnk" /a:c /t:"%SYSTEMROOT%\system32\dxdiag.exe" /d:"DirectX ofrece acceso a las capacidades de las tarjetas de v�deo y de sonido, que permiten a los programas presentar gr�ficos realistas tridimensionales (3-D) y efectos envolventes de m�sica y audio"

echo ----------------------------------------------------------------------

::HTML Help
echo.37 - HTML Help
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\HTML Help.lnk" /a:c /t:"%SYSTEMROOT%\hh.exe" /d:"Abre una pantalla de Ayuda basada en HTML"

echo ----------------------------------------------------------------------

::Express Install Wizard 
echo.38 - IExpress Wizard
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\IExpress Wizard.lnk" /a:c /t:"%SYSTEMROOT%\system32\iexpress.exe" /d:"Permite crear a medida auto-ejecutables de instalaci�n y extracci�n"

echo ----------------------------------------------------------------------

::Remote Access Phone Book
echo.39 - Libreta de tel�fonos de acceso remoto
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Libreta de tel�fonos de acceso remoto.lnk" /a:c /t:"%SYSTEMROOT%\system32\rasphone.exe" /d:"Se puede utilizar para iniciar una conexi�n de red o para crear, editar y borrar entradas en un archivo de una gu�a telef�nica (phone book) (PHB). Los Servicios de Acceso Remoto (RAS) proveen capacidad a las aplicaciones cliente de Windows"

echo ----------------------------------------------------------------------

::Dialer
echo.40 - Marcador telef�nico
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Marcador telef�nico.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\dialer.exe" /d:"Permite a los usuarios marcar una llamada de voz y datos saliente a trav�s de su equipo. El usuario introduce un n�mero a marcar o selecciona un n�mero de la lista y a continuaci�n recoge en un tel�fono la respuesta"

echo ----------------------------------------------------------------------

::Removable Storage Management
echo.41 - Medios de almacenamiento extra�bles
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Medios de almacenamiento extra�bles.lnk" /a:c /t:"%SYSTEMROOT%\system32\ntmsmgr.msc" /d:"Cataloga medios extra�bles y administra bibliotecas automatizadas"

echo ----------------------------------------------------------------------

::Microsoft FrontPage TCP/IP Tester
echo.42 - Microsoft FrontPage TCP-IP Test
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Microsoft FrontPage TCP-IP Test.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\tcptest.exe" /d:"Probador de protocolo de transmisi�n y de Internet"

echo ----------------------------------------------------------------------

::Microsoft IME Dictionary Tool
echo.43 - Microsoft IME Dictionary Tool
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Microsoft IME Dictionary Tool.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\imjpdct.exe" /d:"Diccionario Input Method Editor (IME) que permite ver caracteres y s�mbolos complejos en idioma japon�s, chino simple y tradicional, y coreano utilizando un teclado est�ndar"

echo ----------------------------------------------------------------------

::Microsoft New ChangJie IME
echo.44 - Microsoft New ChangJie IME
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Microsoft New ChangJie IME.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\cintsetp.exe" /d:"Permite teclear caracteres chinos tradicionales en un teclado est�ndar"

echo ----------------------------------------------------------------------

::Microsoft New Phonetic IME 2002a User Define Phrase Tool
echo.45 - Microsoft New Phonetic IME 2002a User Define Phrase Tool
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Microsoft New Phonetic IME 2002a User Define Phrase Tool.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\comrepl.exe" /d:"Herramienta de definici�n de frases en caracteres orientales en un teclado est�ndar"

echo ----------------------------------------------------------------------

::Text to Speach Narrator 
echo.46 - Narrador de Microsoft
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Narrador de Microsoft.lnk" /a:c /t:"%SYSTEMROOT%\system32\narrator.exe" /d:"Programa de conversi�n de texto a voz para usuarios ciegos o con dificultades visuales. Lee el contenido de la ventana activa, opciones de men� o el texto escrito"

echo ----------------------------------------------------------------------

::NetMeeting
echo.47 - NetMeeting Aplicaci�n de charla
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\NetMeeting Aplicaci�n de charla.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\cb32.exe" /d:"Programa cliente de VoIP y de videoconferencia multipunto" 

echo ----------------------------------------------------------------------

::Microsoft FrontPage Server Administration Snapin
echo.48 - Office Web Server Configuration Wizard
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Office Web Server Configuration Wizard.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\cfgwiz.exe" /d:"Configura el Web Server para FrontPage"

echo ----------------------------------------------------------------------

::FTP Transfer 
echo.49 - Programa de transferencia de archivos FTP
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Programa de transferencia de archivos FTP.lnk" /a:c /t:"%SYSTEMROOT%\system32\ftp.exe" /d:"Programa de transferencia de archivos por FTP"

echo ----------------------------------------------------------------------

::Properties for Microsoft IME standard
echo.50 - Propiedades para Microsoft IME standar
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Propiedades para Microsoft IME standar.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\imjpuex.exe" /d:"Microsoft Global Input Method Editor (IME) permite ver caracteres y s�mbolos complejos en idioma japon�s, chino simple y tradicional, y coreano utilizando un teclado est�ndar"

echo ----------------------------------------------------------------------

::Properties for Microsoft Natural Input 2002
echo.51 - Propiedades para Microsoft Natural Input 2002
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Propiedades para Microsoft Natural Input 2002.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\imjputy.exe" /d:"Microsoft Global Input Method Editor (IME) permite ver caracteres y s�mbolos complejos en idioma japon�s, chino simple y tradicional, y coreano utilizando un teclado est�ndar"

echo ----------------------------------------------------------------------

::Microsoft Foundation Class Library (MFC) Application File Information
echo.52 - RegTrace
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\RegTrace.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\EXCH_regtrace.exe" /d:"Utilitario que rastrea el registro en Microsoft Foundation Class Library (MFC)"

echo ----------------------------------------------------------------------

::Windows Media Player 5.1
echo.53 - Reproductor de Windows Media 5.1
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Reproductor de Windows Media 5.1.lnk" /a:c /t:"%SYSTEMROOT%\system32\mplay32.exe" /d:"Reproductor simple de audio y video"

echo ----------------------------------------------------------------------

::Windows Media Player 6.4.9.1126
echo.54 - Reproductor de Windows Media 6.4.9.1126
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Reproductor de Windows Media 6.4.lnk" /a:c /t:"C:\Archivos de programa\Windows Media Player\mplayer2.exe" /d:"Reproductor avanzado de audio y video"

echo ----------------------------------------------------------------------

::Indexing Services 
echo.55 - Servicio de Index Server
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Servicio de Index Server.lnk" /a:c /t:"%SYSTEMROOT%\system32\ciadv.msc" /d:"Proporciona una b�squeda r�pida y flexible en el contenido de archivos y propiedades"

echo ----------------------------------------------------------------------

::Removable Storage Operator Requests
echo.56 - Solicitudes del operador de medios de almacenamiento extra�bles
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Solicitudes del operador de medios de almacenamiento extra�bles.lnk" /a:c /t:"%SYSTEMROOT%\system32\ntmsoprq.msc" /d:"Cataloga medios extra�bles y administra bibliotecas automatizadas"

echo ----------------------------------------------------------------------

::Real-time Communications Share (RTC)
echo.57 - Uso compartido de aplicaciones RTC
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Uso compartido de aplicaciones RTC.lnk" /a:c /t:"%SYSTEMROOT%\system32\rtcshare.exe" /d:"Aplicaci�n para uso compartido de Real-time Communications"

echo ----------------------------------------------------------------------

::Local User and Group Manager
echo.58 - Usuarios locales y grupos
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Usuarios locales y grupos.lnk" /a:c /t:"%SYSTEMROOT%\system32\lusrmgr.msc" /d:"Administra usuarios locales y grupos"

echo ----------------------------------------------------------------------

::Configuration Utility 
echo.59 - Utilidad de configuraci�n del sistema
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Utilidad de configuraci�n del sistema.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\msconfig.exe" /d:"Esta utilidad soluciona el proceso de inicio modificando los programas, ciertos archivos de configuraci�n y simplifica los controles sobre los servicios de Windows"

echo ----------------------------------------------------------------------

::DNS Lookup
echo.60 - Ver DNS
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Ver DNS.lnk" /a:c /t:"%SYSTEMROOT%\system32\nslookup.exe" /d:"Busca un nombre de dominio que est� asociado con una direcci�n IP usando el Domain Name System (DNS) de Internet"

echo ----------------------------------------------------------------------

::Clipboard Viewer 
echo.61 - Visor del Portafolios (Portapapeles)
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Visor del Portafolios (Portapapeles).lnk" /a:c /t:"%SYSTEMROOT%\system32\clipbrd.exe" /d:"Muestra el Portapapeles"

echo ----------------------------------------------------------------------

::Windows Management Infrastructure (WMI)
echo.62 - Windows Management Infrastructure (WMI)
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Men� Inicio\Programas\Accesorios\Aplicaciones Ocultas XP\Windows Management Infrastructure (WMI).lnk" /a:c /t:"%SYSTEMROOT%\system32\wmimgmt.msc" /d:"Es un conjunto de extensiones al Modelo de Controladores de Windows que proporciona al sistema operativo una interfaz a trav�s de la cual los componentes instrumentados proveen informaci�n y notificaci�n"

echo ----------------------------------------------------------------------
echo.
echo                         Instalaci�n finalizada
echo.
echo ----------------------------------------------------------------------
echo.

pause

exit