Windows XP Hidden Applications

Installs shortcuts to programs that are not installed by default in Windows XP (Home or Professional).

Works only for Windows XP Service Pack 3 as a full install. After completing the standard installation go to Control Panel > Add or Remove Programs > Add/Remove Windows Components and tick all the options. If you do not label some of them, the associated shortcuts will not work.

Unzip the .zip file with WinZip or a similar program.

Do not remove the program Shortcut.exe because otherwise the installation will not work.

To install double click on Windows XP Hidden Applications.cmd and after it finishes press any key to exit.

The shortcuts will appear in Start > All Programs > Accessories > Windows XP Hidden Applications

Copyright � 2010 - � DI-DA-DO Computaci�n

Buenos Aires, Argentina

Contact: didadocom@yahoo.com

Web: http://www.didado.com.ar/ingles.html

Ended on 30/07/2010

