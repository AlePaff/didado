cls

::Installs shortcuts to programs that are not installed by default in Windows XP (Home or Professional)
::Only for Windows XP Service Pack 3 with complete installation
::� 2010 - � DI-DA-DO Computaci�n
::Buenos Aires, Argentina
::didadocom@yahoo.com
::30/07/2010

@echo off

color 47

title Windows XP Hidden Applications

echo.
echo ------------------------ DI-DA-DO Computaci�n ------------------------
echo.
echo.               Windows XP Hidden Applications Installer
echo.
echo ----------------------------------------------------------------------

If Not Exist "%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications" (Md "%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications")

echo.01 - About Windows
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\About Windows.lnk" /a:c /t:"%SYSTEMROOT%\system32\winver.exe" /d:"Microsoft Windows XP version"

echo ----------------------------------------------------------------------

echo.02 - Accounts Database Encryption
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Accounts Database Encryption.lnk" /a:c /t:"%SYSTEMROOT%\system32\syskey.exe" /d:"Encrypts Windows XP Account Database"

echo ----------------------------------------------------------------------

echo.03 - BlueTooth File Transfer Wizard
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\BlueTooth File Transfer Wizard.lnk" /a:c /t:"%SYSTEMROOT%\system32\fsquirt.exe" /d:"Bluetooth Wizard, used to connect up wireless Bluetooth devices on the PC"

echo ----------------------------------------------------------------------

echo.04 - Certificates
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Certificates.lnk" /a:c /t:"%SYSTEMROOT%\system32\certmgr.msc" /d:"Manages certificates involved in security"

echo ----------------------------------------------------------------------

echo.05 - Chat 
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Chat .lnk" /a:c /t:"%SYSTEMROOT%\system32\winchat.exe" /d:"Chat with other computers on your workgroup"

echo ----------------------------------------------------------------------

echo.06 - ClipBook Viewer 
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\ClipBook Viewer.lnk" /a:c /t:"%SYSTEMROOT%\system32\clipbrd.exe" /d:"View-Delete contents in the clipboook"

echo ----------------------------------------------------------------------

echo.07 - Create a Briefcase
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Create a Briefcase.lnk" /a:c /t:"%SYSTEMROOT%\system32\syncapp.exe" /d:"Enable multiple copies of a specified file in two or more locations to automatically update-synchronize and be the same"

echo ----------------------------------------------------------------------

echo.08 - DirectX Diagnostic Tool
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\DirectX Diagnostic Tool.lnk" /a:c /t:"%SYSTEMROOT%\system32\dxdiag.exe" /d:"Help troubleshoot DirectX-related (video or sound) related hardware problems"

echo ----------------------------------------------------------------------

echo.09 - Disk Management 
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Disk Management.lnk" /a:c /t:"%SYSTEMROOT%\system32\diskmgmt.msc" /d:"Opens disk management utility "

echo ----------------------------------------------------------------------

echo.10 - DNS Lookup
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\DNS Lookup.lnk" /a:c /t:"%SYSTEMROOT%\system32\nslookup.exe" /d:"Tool for testing and troubleshooting DNS servers"

echo ----------------------------------------------------------------------

echo.11 - Dr. Watson
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Dr. Watson.lnk" /a:c /t:"%SYSTEMROOT%\system32\drwatson.exe" /d:"Configures crash log dump settings 16 bit"

echo ----------------------------------------------------------------------

echo.12 - Dr. Watson for Windows
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Dr. Watson for Windows.lnk" /a:c /t:"%SYSTEMROOT%\system32\drwtsn32.exe" /d:"Configures crash log dump settings 32 bit"

echo ----------------------------------------------------------------------

echo.13 - Driver Verifier Manager
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Driver Verifier Manager.lnk" /a:c /t:"%SYSTEMROOT%\system32\verifier.exe" /d:"Creates, displays, and deletes settings to verify your drivers"

echo ----------------------------------------------------------------------

echo.14 - Event to Trap Translator
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Event to Trap Translator.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\evntwin.exe" /d:"Monitor events recorded in the application, security and system logs"

echo ----------------------------------------------------------------------

echo.15 - Express Install Wizard
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Express Install Wizard.lnk" /a:c /t:"%SYSTEMROOT%\system32\iexpress.exe" /d:"Creates and opens self-extracting-installing packages"

echo ----------------------------------------------------------------------

echo.16 - File Signature Verification 
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\File Signature Verification.lnk" /a:c /t:"%SYSTEMROOT%\system32\sigverif.exe" /d:"Checks and verifies file security signatures"

echo ----------------------------------------------------------------------

echo.17 - Front Page Extensions Manager
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Front Page Extensions Manager.lnk" /a:c /t:"C:\Program Files\Common Files\Microsoft Shared\web server extensions\40\bin\fpmmc.msc" /d:"Server-side programs that allow the Microsoft FrontPage client software to interact with the extensions for content updates and authoring"

echo ----------------------------------------------------------------------

echo.18 - FTP Transfer 
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\FTP Transfer.lnk" /a:c /t:"%SYSTEMROOT%\system32\ftp.exe" /d:"Transfers files to and from a computer running a File Transfer Protocol (FTP) server service such as Internet Information Services"

echo ----------------------------------------------------------------------

echo.19 - Group Convert
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Group Convert.lnk" /a:c /t:"%SYSTEMROOT%\system32\grpconv.exe" /d:"Converts the Windows 3.x groups to folders. Works only on Windows XP and Windows XP Service Pack 1"

echo ----------------------------------------------------------------------

echo.20 - Group Policy
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Group Policy.lnk" /a:c /t:"%SYSTEMROOT%\system32\gpedit.msc" /d:"Manages user and computer permissions and privileges"

echo ----------------------------------------------------------------------

echo.21 - HTML Help
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\HTML Help.lnk" /a:c /t:"%SYSTEMROOT%\hh.exe" /d:"Developed by Microsoft and first released in 1997 as a successor to the Microsoft WinHelp format"

echo ----------------------------------------------------------------------

echo.22 - Indexing Service
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Indexing Service.lnk" /a:c /t:"%SYSTEMROOT%\system32\ciadv.msc" /d:"Manages the Indexing Service"

echo ----------------------------------------------------------------------

echo.23 - Legacy Program Manager
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Legacy Program Manager.lnk" /a:c /t:"%SYSTEMROOT%\system32\progman.exe" /d:"Legacy desktop shell for Windows 3x, Windows for Workgroups and Windows NT 3.51. Works only on Windows XP and Windows XP Service Pack 1"

echo ----------------------------------------------------------------------

echo.24 - Local Users and Groups
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Local Users and Groups.lnk" /a:c /t:"%SYSTEMROOT%\system32\lusrmgr.msc" /d:"Control local users and some of their settings"

echo ----------------------------------------------------------------------

echo.25 - Local Security Settings
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Local Security Settings.lnk" /a:c /t:"%SYSTEMROOT%\system32\secpol.msc" /d:"Extends Group Policy snap and helps to define local security policies"

echo ----------------------------------------------------------------------

echo.26 - Microsoft Foundation Class Library Application
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Microsoft Foundation Class Library Application.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\EXCH_regtrace.exe" /d:"Utility that searches the registry in Microsoft Foundation Class Library (MFC)"

echo ----------------------------------------------------------------------

echo.27 - Microsoft FrontPage Server Administration Snapin
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Microsoft FrontPage Server Administration Snapin.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\cfgwiz.exe" /d:"Configures the Web Server for FrontPage"

echo ----------------------------------------------------------------------

echo.28 - Microsoft FrontPage TCP-IP Tester
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Microsoft FrontPage TCP-IP Tester.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\tcptest.exe" /d:"Transmission protocol tester"

echo ----------------------------------------------------------------------

echo.29 - Microsoft IME Dictionary Tool
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Microsoft IME Dictionary Tool.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\imjpdct.exe" /d:"Diccionary to enter complex characters and symbols, such as Japan characters, using a standard keyboard"

echo ----------------------------------------------------------------------

echo.30 - Microsoft New ChangJie IME
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Microsoft New ChangJie IME.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\cintsetp.exe" /d:"Allows computer users to enter complex characters and symbols, such as Japan characters, using a standard keyboard"

echo ----------------------------------------------------------------------

echo.31 - Microsoft New Phonetic IME 2002a User Define Phrase Tool
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Microsoft New Phonetic IME 2002a User Define Phrase Tool.lnk" /a:c /t:"%SYSTEMROOT%\system32\com\comrepl.exe" /d:"User Define Phrase Tool to enter complex characters and symbols, such as Japan characters, using a standard keyboard"

echo ----------------------------------------------------------------------

echo.32 - MS-DOS Editor
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\MS-DOS Editor.lnk" /a:c /t:"%SYSTEMROOT%\system32\edit.com" /d:"MS-DOS text editor"

echo ----------------------------------------------------------------------

echo.33 - Narrator 
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Narrator.lnk" /a:c /t:"%SYSTEMROOT%\system32\narrator.exe" /d:"Text to speech conversion for users who are blind or visually impaired. Reads the active window contents, menu options or the written text"

echo ----------------------------------------------------------------------

echo.34 - NetMeeting
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\NetMeeting.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\cb32.exe" /d:"A VoIP and multi-point videoconferencing client"

echo ----------------------------------------------------------------------

echo.35 - Network Diagnostics for Windows XP
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Network Diagnostics for Windows XP.lnk" /a:c /t:"%SYSTEMROOT%\Network Diagnostic\xpnetdiag.exe" /d:"Helps you identify and fix connection problems on a home network that connects to the Internet"

echo ----------------------------------------------------------------------

echo.36 - Network Sharing Wizard
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Network Sharing Wizard.lnk" /a:c /t:"%SYSTEMROOT%\system32\shrpubw.exe" /d:"Provides automated, step-by-step procedures for enabling a specified folder to be accessed by other computers in the network"

echo ----------------------------------------------------------------------

echo.37 - Object Packager 
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Object Packager.lnk" /a:c /t:"%SYSTEMROOT%\system32\packager.exe" /d:"Packages objects for insertion into files"

echo ----------------------------------------------------------------------

echo.38 - Phone Dialer
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Phone Dialer.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\dialer.exe" /d:"Allows a user to dial an outgoing voice call via his computer, if the modem supports both voice and data"

echo ----------------------------------------------------------------------

echo.39 - Private Character Editor 
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Private Character Editor.lnk" /a:c /t:"%SYSTEMROOT%\system32\eudcedit.exe" /d:"Creates and edits new characters for insertion into documents"

echo ----------------------------------------------------------------------

echo.40 - Properties for Microsoft IME Standard
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Properties for Microsoft IME Standard.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\imjpuex.exe" /d:"Allows computer users to enter complex characters and symbols, such as Japan characters, using a standard keyboard"

echo ----------------------------------------------------------------------

echo.41 - Properties for Microsoft Natural Input 2002
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Properties for Microsoft Natural Input 2002.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\imjputy.exe" /d:"Allows computer users to enter complex characters and symbols, such as Japan characters, using a standard keyboard"

echo ----------------------------------------------------------------------

echo.42 - Real-time Communications Share (RTC)
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Real-time Communications Share (RTC).lnk" /a:c /t:"%SYSTEMROOT%\system32\rtcshare.exe" /d:"Real-time Communications Share (RTC)"

echo ----------------------------------------------------------------------

echo.43 - Registry Editor
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Registry Editor.lnk" /a:c /t:"%SYSTEMROOT%\system32\regedt32.exe" /d:"Create, view, and modify registry values"

echo ----------------------------------------------------------------------

echo.44 - Remote Access Phone Book
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Remote Access Phone Book.lnk" /a:c /t:"%SYSTEMROOT%\system32\rasphone.exe" /d:"Allows connections to a network phone book"

echo ----------------------------------------------------------------------

echo.45 - Removable Storage
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Removable Storage.lnk" /a:c /t:"%SYSTEMROOT%\system32\ntmsmgr.msc" /d:"Catalogs removable media and operates automated libraries"

echo ----------------------------------------------------------------------

echo.46 - Removable Storage Operator Requests
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Removable Storage Operator Requests.lnk" /a:c /t:"%SYSTEMROOT%\system32\ntmsoprq.msc" /d:"Catalogs removable media and operates automated libraries utility"

echo ----------------------------------------------------------------------

echo.47 - Resultant Set of Policy
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Resultant Set of Policy.lnk" /a:c /t:"%SYSTEMROOT%\system32\rsop.msc" /d:"Complements the Group Policy implementations"

echo ----------------------------------------------------------------------

echo.48 - Scanner and Camera Wizard
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Scanner and Camera Wizard.lnk" /a:c /t:"%SYSTEMROOT%\system32\wiaacmgr.exe" /d:"Used in acquiring images from digital scanners and cameras"

echo ----------------------------------------------------------------------

echo.49 - Shared Folders
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Shared Folders.lnk" /a:c /t:"%SYSTEMROOT%\system32\fsmgmt.msc" /d:"Shows all the shared folders of the computer in one single window"

echo ----------------------------------------------------------------------

echo.50 - SQL Server Client Network Utility
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\SQL Server Client Network Utility.lnk" /a:c /t:"%SYSTEMROOT%\system32\cliconfg.exe" /d:"Tool for configuring client connections to network SQL Server"

echo ----------------------------------------------------------------------

echo.51 - System Configuration Editor 
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\System Configuration Editor.lnk" /a:c /t:"%SYSTEMROOT%\system32\sysedit.exe" /d:"Modify SYSTEM.INI, WIN.INI, CONFIG.SYS and AUTOEXEC.BAT"

echo ----------------------------------------------------------------------

echo.52 - System Configuration Utility
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\System Configuration Utility.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\msconfig.exe" /d:"Controls services and startup programs"

echo ----------------------------------------------------------------------

echo.53 - Telnet Client 
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Telnet Client.lnk" /a:c /t:"%SYSTEMROOT%\system32\telnet.exe" /d:"Connects to Telnet networks"

echo ----------------------------------------------------------------------

echo.54 - Windows Help 16 bit
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Windows Help 16 bit.lnk" /a:c /t:"%SYSTEMROOT%\winhelp.exe" /d:"Required to display 16 bit Help files that have the (.hlp) file name extension"

echo ----------------------------------------------------------------------

echo.55 - Windows Help 32 bit
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Windows Help 32 bit bit.lnk" /a:c /t:"%SYSTEMROOT%\winhlp32.exe" /d:"Required to display 32 bit Help files that have the (.hlp) file name extension"

echo ----------------------------------------------------------------------

echo.56 - Windows Management Infrastructure (WMI)
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Windows Management Infrastructure (WMI).lnk" /a:c /t:"%SYSTEMROOT%\system32\wmimgmt.msc" /d:"Collects and provides system management information by tracking applications and drivers"

echo ----------------------------------------------------------------------

echo.57 - Windows Management Instrumentation Test
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Windows Management Instrumentation Test.lnk" /a:c /t:"%SYSTEMROOT%\system32\dllcache\wbemtest.exe" /d:"A Windows Management Instrumentation Test Tool"

echo ----------------------------------------------------------------------

echo.58 - Windows Media Player 5.1
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Windows Media Player 5.1.lnk" /a:c /t:"%SYSTEMROOT%\system32\mplay32.exe" /d:"Very basic and plain version of Windows Media Player"

echo ----------------------------------------------------------------------

echo.59 - Windows Media Player 6.4.9.1126
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Windows Media Player 6.4.lnk" /a:c /t:"C:\Program Files\Windows Media Player\mplayer2.exe" /d:"Basic version of Windows Media Player"

echo ----------------------------------------------------------------------

echo.60 - Windows NT NetDDE Share Manager
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Windows NT NetDDE Share Manager.lnk" /a:c /t:"%SYSTEMROOT%\system32\ddeshare.exe" /d:"Manages the way programs communicate and share data"

echo ----------------------------------------------------------------------

echo.61 - Windows Script Host
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Windows Script Host.lnk" /a:c /t:"%SYSTEMROOT%\system32\wscript.exe" /d:"Enables scripts to be run directly in Windows by double-clicking a script file or by typing the name of a script file at a command prompt"

echo ----------------------------------------------------------------------

echo.62 - Windows Task Manager 
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Hidden Applications\Windows Task Manager .lnk" /a:c /t:"%SYSTEMROOT%\system32\taskmgr.exe" /d:"Displays information about the processes and programs running in your system"

echo ----------------------------------------------------------------------
echo. 
echo                                 Finish
echo.
echo ----------------------------------------------------------------------
echo.

pause

exit