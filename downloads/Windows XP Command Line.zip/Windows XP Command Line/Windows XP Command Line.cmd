cls

::Installs shortcuts to Command Lines in Windows XP (Home or Professional)
::Only for Windows XP Service Pack 3 with complete installation
::� 2010 - � DI-DA-DO Computaci�n
::Buenos Aires, Argentina
::didadocom@yahoo.com
::30/07/2010

@echo off

color 0F

title Windows XP Command Line

echo.
echo ------------------------ DI-DA-DO Computaci�n ------------------------
echo.
echo.                  Windows XP Command Line Installer
echo.
echo ----------------------------------------------------------------------

If Not Exist "%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line" (md "%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line")

echo.001 - Append
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Append.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k append /?" /d:"Allows programs to open data files in specified directories as if they were in the current directory"

echo ----------------------------------------------------------------------

echo.002 - Arp
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Arp.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k arp /?" /d:"Displays and modifies the IP-to-Physical address translation tables used by address resolution protocol"

echo ----------------------------------------------------------------------

echo.003 - Asr_fmt 
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Asr_fmt.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k asr_fmt /?" /d:"The Automated System Recovery utility"

echo ----------------------------------------------------------------------

echo.004 - Asr_ldm
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Asr_ldm.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k asr_ldm /?" /d:"The Logical Disk Manager ASR utility"

echo ----------------------------------------------------------------------

echo.005 - Assoc
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Assoc.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k assoc /?" /d:"Displays or modifies file extension asssociations"

echo ----------------------------------------------------------------------

echo.006 - At
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\At.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k at /?" /d:"Schedules commands and programs to run on a computer at a specified time and date. The Scheduler service must be running"

echo ----------------------------------------------------------------------

echo.007 - Atmadm
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Atmadm.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k atmadm /?" /d:"The ATM Call Manager utility"

echo ----------------------------------------------------------------------

echo.008 - Attrib
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Attrib.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k attrib /?" /d:"Displays or changes file attributes"

echo ----------------------------------------------------------------------

echo.009 - Auditusr
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Auditusr.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k auditusr /?" /d:"Sets per user auditing policy"

echo ----------------------------------------------------------------------

echo.010 - Blastcln
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Blastcln.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k blastcln /?" /d:"Removes the Blaster and Nachi worm infections"

echo ----------------------------------------------------------------------

echo.011 - Bootcfg
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Bootcfg.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k bootcfg /?" /d:"Can be used to configure, query, change or delete the boot entry settings in the BOOT.INI file"

echo ----------------------------------------------------------------------

echo.012 - Break
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Break.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k break /?" /d:"Sets or Clears Ctrl+C checking on DOS system"

echo ----------------------------------------------------------------------

echo.013 - Cacls
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Cacls.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k cacls /?" /d:"Displays or modifies access control lists (ACLs) of files"

echo ----------------------------------------------------------------------

echo.014 - Call
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Call.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k call /?" /d:"Call one batch program from another"

echo ----------------------------------------------------------------------

echo.015 - Cd
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Cd.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k cd /?" /d:"Displays the name of or changes the current directory"

echo ----------------------------------------------------------------------

echo.016 - Chcp
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Chcp.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k chcp /?" /d:"Displays or sets the active code page number"

echo ----------------------------------------------------------------------

echo.017 - Chdir
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Chdir.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k chdir /?" /d:"Displays the name of or changes the current directory"

echo ----------------------------------------------------------------------

echo.018 - Chkdsk
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Chkdsk.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k chkdsk /?" /d:"Checks a disk and displays a status report"

echo ----------------------------------------------------------------------

echo.019 - Chkntfs
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Chkntfs.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k chkntfs /?" /d:"Displays or modifies the checking of disk at boot time"

echo ----------------------------------------------------------------------

echo.020 - Cipher
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Cipher.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k cipher /?" /d:"Displays or alters the encryption of directories on NTFS partitions"

echo ----------------------------------------------------------------------

echo.021 - Cls
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Cls.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k cls /?" /d:"Clears the screen"

echo ----------------------------------------------------------------------

echo.022 - Clspack
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Clspack.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k clspack /?" /d:"Utility for creating new classes.zip folder in Classes"

echo ----------------------------------------------------------------------

echo.023 - Cmd
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Cmd.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k cmd /?" /d:"Starts a new instance of the Windows XP command interpreter"

echo ----------------------------------------------------------------------

echo.024 - Cmstp
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Cmstp.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k cmstp /?" /d:"Installs and configures Connection Manager service profiles"

echo ----------------------------------------------------------------------

echo.025 - Color
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Color.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k color /?" /d:"Sets the default console foreground and background colors"

echo ----------------------------------------------------------------------

echo.026 - Command
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Command.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k command /?" /d:"Starts a new instance of the MS-DOS command interpreter"

echo ----------------------------------------------------------------------

echo.027 - Comp
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Comp.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k comp /?" /d:"Compares the contents of two files or sets of files"

echo ----------------------------------------------------------------------

echo.028 - Compact
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Compact.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k compact /?" /d:"Displays or alters the compression of files on NTFS partitions"

echo ----------------------------------------------------------------------

echo.029 - Convert
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Convert.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k convert /?" /d:"Converts FAT volumes to NTFS"

echo ----------------------------------------------------------------------

echo.030 - Convlog
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Convlog.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k convlog /?" /d:"Used to convert log files to NCSA format"

echo ----------------------------------------------------------------------

echo.031 - Copy
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Copy.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k copy /?" /d:"Copies one or more files to another location"

echo ----------------------------------------------------------------------

echo.032 - Cscript
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Cscript.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k cscript /?" /d:"A command line version of the Windows Script Host that enables you to run previously created VBScript and JScript from the command line"

echo ----------------------------------------------------------------------

echo.033 - Date
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Date.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k date /?" /d:"Displays or sets the date"

echo ----------------------------------------------------------------------

echo.034 - Debug
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Debug.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k debug /?" /d:"A program testing and editing tool"

echo ----------------------------------------------------------------------

echo.035 - Defrag
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Defrag.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k defrag /?" /d:"Defragment a hard drive"

echo ----------------------------------------------------------------------

echo.036 - Del
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Del.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k del /?" /d:"Delete one or more files"

echo ----------------------------------------------------------------------

echo.037 - Diantz
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Diantz.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k diantz /?" /d:"Utility to compress files and insert the files into a single .CAB file"

echo ----------------------------------------------------------------------

echo.038 - Dir
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Dir.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k dir /?" /d:"Displays a list of files subdirectories in a directory"

echo ----------------------------------------------------------------------

echo.039 - Diskcomp
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Diskcomp.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k diskcomp /?" /d:"Compares the contents of two floppy disks"

echo ----------------------------------------------------------------------

echo.040 - Diskcopy
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Diskcopy.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k diskcopy /?" /d:"Copies the contents of one floppy disk to another"

echo ----------------------------------------------------------------------

echo.041 - Diskpart
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Diskpart.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k diskpart /?" /d:"Disk administration"

echo ----------------------------------------------------------------------

echo.042 - Diskperf
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Diskperf.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k diskperf /?" /d:"Used to switch performance counters for the disk subsystem on and off"

echo ----------------------------------------------------------------------

echo.043 - Dnslookup
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Dnslookup.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k dnslookup /?" /d:"Command to query the Domain Name Service for information about  domain names and IP addresses"

echo ----------------------------------------------------------------------

echo.044 - Doskey
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Doskey.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k doskey /?" /d:"Edits command lines, recalls Windows XP commands, and creates macros"

echo ----------------------------------------------------------------------

echo.045 - Dosx
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Dosx.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k dosx /?" /d:"A virtual DOS machine (VDM) MS-DOS extender for standard mode"

echo ----------------------------------------------------------------------

echo.046 - Driverquery
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Driverquery.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k driverquery /?" /d:"Enumerate and display the list of installed device drivers as well as their properties"

echo ----------------------------------------------------------------------

echo.047 - Echo
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Echo.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k echo /?" /d:"Displays messages, or turns command-echoing on or off"

echo ----------------------------------------------------------------------

echo.048 - Edit
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Edit.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k edit /?" /d:"MS-DOS editor"

echo ----------------------------------------------------------------------

echo.049 - Edlin
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Edlin.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k edlin /?" /d:"A line-oriented text editor"

echo ----------------------------------------------------------------------

echo.050 - Endlocal
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Endlocal.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k endlocal /?" /d:"Ends localization of environment changes in a batch file"

echo ----------------------------------------------------------------------

echo.051 - Erase
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Erase.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k erase /?" /d:"Delete one or more files"

echo ----------------------------------------------------------------------

echo.052 - Esentutl
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Esentutl.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k esentutl /?" /d:"Maintenance utilities for Microsoft Windows databases"

echo ----------------------------------------------------------------------

echo.053 - Eventcreate
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Eventcreate.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k eventcreate /?" /d:"Create a custom event ID and message in a specified event log"

echo ----------------------------------------------------------------------

echo.054 - Eventtriggers
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Eventtriggers.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k eventtriggers /?" /d:"This application displays and configures Event Triggers on local or remote system"

echo ----------------------------------------------------------------------

echo.055 - Evntcmd
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Evntcmd.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k evntcmd /?" /d:"Configures the translation of events to traps, trap destinations, or both based on information in a configuration file"

echo ----------------------------------------------------------------------

echo.056 - Exe2bin
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Exe2bin.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k exe2bin /?" /d:"Converts .EXE files to binary format"

echo ----------------------------------------------------------------------

echo.057 - Exit
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Exit.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k exit /?" /d:"Quits the CMD.EXE program or the current batch script"

echo ----------------------------------------------------------------------

echo.058 - Expand
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Expand.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k expand /?" /d:"Expands one or more compressed files"

echo ----------------------------------------------------------------------

echo.059 - Extract16
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Extract16.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k extract /?" /d:"Uncompress .CAB files 16 bit"

echo ----------------------------------------------------------------------

echo.060 - Extrac32
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Extrac32.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k extrac32 /?" /d:"Uncompress .CAB files 32 bit"

echo ----------------------------------------------------------------------

echo.061 - Fastopen
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Fastopen.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k fastopen /?" /d:"An MS-DOS utility that improves performance on systems that have large folders by decreasing the time it takes to open frequently accessed files"

echo ----------------------------------------------------------------------

echo.062 - Fc
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Fc.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k fc /?" /d:"Compares two files or sets of files and displays the differences between them"

echo ----------------------------------------------------------------------

echo.063 - Find
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Find.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k find /?" /d:"Searches for a text string in a file or files"

echo ----------------------------------------------------------------------

echo.064 - Findstr
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Findstr.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k findstr /?" /d:"Searches for strings in files"

echo ----------------------------------------------------------------------

echo.065 - Finger
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Finger.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k finger /?" /d:"A TCP-IP utility used to obtain information about a user account via a remote system"

echo ----------------------------------------------------------------------

echo.066 - Fltmc
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Fltmc.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k fltmc /?" /d:"Lad and unload minifilters, attach-detach minifilters to-from volumes, enumerate minifilters, instances, volumes"

echo ----------------------------------------------------------------------

echo.067 - Fontview
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Fontview.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k fontview /?" /d:"Displays a sample output for a font in a printable GUI window"

echo ----------------------------------------------------------------------

echo.068 - For
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\For.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k for /?" /d:"Runs a specified command for each file in a set of files"

echo ----------------------------------------------------------------------

echo.069 - Forcedos
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Forcedos.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k forcedos /?" /d:"Instructs Windows XP to launch an application as an MS-DOS utility when it contains the code for both OS/2 and MS-DOS"

echo ----------------------------------------------------------------------

echo.070 - Format
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Format.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k format /?" /d:"Formats a disk for use with Windows XP"

echo ----------------------------------------------------------------------

echo.071 - Fsutil
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Fsutil.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k fsutil /?" /d:"File and Volume utilities"

echo ----------------------------------------------------------------------

echo.072 - Ftype
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Ftype.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ftype /?" /d:"Displays or modifies file types used in file extension associations"

echo ----------------------------------------------------------------------

echo.073 - Getmac
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Getmac.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k getmac /?" /d:"Displays the Media Access Control (MAC) address for one or more network adapters on a system"

echo ----------------------------------------------------------------------

echo.074 - Goto
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Goto.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k goto /?" /d:"Directs cmd.exe to a labeled line in a batch program"

echo ----------------------------------------------------------------------

echo.075 - Gpresult
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Gpresult.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k gpresult /?" /d:"Displays the Resultant Set of Policy (RSoP) for a target user and computer"

echo ----------------------------------------------------------------------

echo.076 - Gpupdate
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Gpupdate.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k gpupdate /?" /d:"Refreshes Group Policies settings"

echo ----------------------------------------------------------------------

echo.077 - Graftabl
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Graftabl.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k graftabl /?" /d:"Enables Windows to display an extended character set in graphics mode"

echo ----------------------------------------------------------------------

echo.078 - Graphics
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Graphics.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k graphics /?" /d:"Loads a program that can print graphics"

echo ----------------------------------------------------------------------

echo.079 - Help
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Help.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k help /?" /d:"Provides help information for Windows XP commands"

echo ----------------------------------------------------------------------

echo.080 - Hostname
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Hostname.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k hostname /?" /d:"Use the Network Control Panel Applet to set hostname"

echo ----------------------------------------------------------------------

echo.081 - If
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\If.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k if /?" /d:"Performs conditional processing in batch programs"

echo ----------------------------------------------------------------------

echo.082 - Iisreset
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Iisreset.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k iisreset /?" /d:"The reset and restart IIS command is used to control the IIS service"

echo ----------------------------------------------------------------------

echo.083 - Ipconfig
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Ipconfig.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ipconfig /?" /d:"Configure IP"

echo ----------------------------------------------------------------------

echo.084 - Ipsec6
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Ipsec6.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ipsec6 /?" /d:"A tool for configuring IPv6 security"

echo ----------------------------------------------------------------------

echo.085 - Ipseccmd
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Ipseccmd.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ipseccmd /?" /d:"Configures Internet Protocol Security (IPSec) policies in a directory service or in a local or remote registry"

echo ----------------------------------------------------------------------

echo.086 - Ipv6
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Ipv6.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ipv6 /?" /d:"A tool to install and configure IPv6"

echo ----------------------------------------------------------------------

echo.087 - Ipxroute
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Ipxroute.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ipxroute /?" /d:"Displays and modifies information about the routing tables used by the IPX protocol"

echo ----------------------------------------------------------------------

echo.088 - KB16
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\KB16.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k kb16 /?" /d:"Configures a keyboard for a specific language"

echo ----------------------------------------------------------------------

echo.089 - Label
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Label.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k label /?" /d:"Creates, changes, or deletes the volume label of a disk"

echo ----------------------------------------------------------------------

echo.090 - Loadfix
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Loadfix.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k loadfix /?" /d:"Loads a program above the first 64K of memory, and runs the program"

echo ----------------------------------------------------------------------

echo.091 - Locator
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Locator.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k locator /?" /d:"Adds support for Remote Procedure Calls (RPCs) to the Windows XP environment"

echo ----------------------------------------------------------------------

echo.092 - Lodctr
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Lodctr.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k lodctr /?" /d:"Updates Performance Monitor counter names and explain text for an extensible counter"

echo ----------------------------------------------------------------------

echo.093 - Logman
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Logman.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k logman /?" /d:"Manages the Performance Logs and Alerts service for creating and managing Event Trace Session logs and Performance logs"

echo ----------------------------------------------------------------------

echo.094 - Logoff
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Logoff.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k logoff /?" /d:"Terminate a session"

echo ----------------------------------------------------------------------

echo.095- Lpq
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Lpq.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k lpq /?" /d:"Displays the state of a remote LPQ queue"

echo ----------------------------------------------------------------------

echo.096 - Lpr
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Lpr.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k lpr /?" /d:"Sends a print job to a network printer"

echo ----------------------------------------------------------------------

echo.097 - Makecab
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Makecab.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k makecab /?" /d:"Creates .cab files for install packages"

echo ----------------------------------------------------------------------

echo.098 - Md
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Md.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k md /?" /d:"Create new folders"

echo ----------------------------------------------------------------------

echo.099 - Mem
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Mem.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k mem /?" /d:"Displays the amount of used and free memory in your system"

echo ----------------------------------------------------------------------

echo.100 - Mkdir
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Mkdir.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k mkdir /?" /d:"Creates any intermediate directories in the path"

echo ----------------------------------------------------------------------

echo.101 - Mode
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Mode.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k mode /?" /d:"Configure system devices"

echo ----------------------------------------------------------------------

echo.102 - Mofcomp
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Mofcomp.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k mofcomp /?" /d:"The Managed Object Format Compiler parses a file containing MOF statements, converts the classes and instances defined in the file to Java classes, and adds the Java classes to the CIM Object Manager Repository"

echo ----------------------------------------------------------------------

echo.103 - More
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\More.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k more /?" /d:"Displays output one screen at a time"

echo ----------------------------------------------------------------------

echo.104 - Mountvol
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Mountvol.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k mountvol /?" /d:"Creates, deletes, or lists a volume mount point"

echo ----------------------------------------------------------------------

echo.105 - Move
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Move.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k move /?" /d:"Moves files and renames files and directories"

echo ----------------------------------------------------------------------

echo.106 - Mqbkup
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Mqbkup.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k mqbkup /?" /d:"A backup and restore utility for Microsoft Message Queuing (MSMQ) service messages"

echo ----------------------------------------------------------------------

echo.107 - Mqsvc
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Mqsvc.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k mqsvc /?" /d:"A messaging service between source and destination computers running distributed applications"

echo ----------------------------------------------------------------------

echo.108 - Mqtgsvc
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Mqtgsvc.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k mqtgsvc /?" /d:"Message queuing trigger service"

echo ----------------------------------------------------------------------

echo.109 - Mrinfo
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Mrinfo.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k mrinfo /?" /d:"To query a multicast router about its interfaces"

echo ----------------------------------------------------------------------

echo.110 - Msg
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Msg.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k msg /?" /d:"Send a message to a user"

echo ----------------------------------------------------------------------

echo.111 - Msiexec
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Msiexec.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k msiexec /?" /d:"Microsoft Windows Installer"

echo ----------------------------------------------------------------------

echo.112 - Nbtstat
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Nbtstat.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k nbtstat /?" /d:"Displays protocol statistics and current TCP-IP connections using NetBIOS over TCP-IP"

echo ----------------------------------------------------------------------

echo.113 - Net
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Net.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k net /?" /d:"Manage network resources"

echo ----------------------------------------------------------------------

echo.114 - Net1
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Net1.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k net1 /?" /d:"Another network command utility that performs the same functions as NET.EXE"

echo ----------------------------------------------------------------------

echo.115 - Netsh
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Netsh.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k netsh /?" /d:"Configure Network Interfaces, Windows Firewall & Remote access"

echo ----------------------------------------------------------------------

echo.116 - Netstat
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Netstat.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k netstat /?" /d:"Displays protocol statistics and current TCP-IP network connections"

echo ----------------------------------------------------------------------

echo.117 - Nlsfunc
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Nlsfunc.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k nlsfunc /?" /d:"Loads country specific information"

echo ----------------------------------------------------------------------

echo.118 - Ntsd
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Ntsd.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ntsd /?" /d:"A troubleshooting utility that gives a detailed view of the system state at the moment of failure"

echo ----------------------------------------------------------------------

echo.119 - Ntvdm
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Ntvdm.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ntvdm /?" /d:"An executable that provides the VDM used to host MS-DOS applications and Windows-on-Windows"

echo ----------------------------------------------------------------------

echo.120 - Nw16
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Nw16.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k nw16 /?" /d:"The NetWare VDM Redirector"

echo ----------------------------------------------------------------------

echo.121 - Nwscript
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Nwscript.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k nwscript /?" /d:"A tool to allow logons to a NetWare server from a Windows PC"

echo ----------------------------------------------------------------------

echo.122 - Odbcconf
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Odbcconf.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k odbcconf /?" /d:"Used to reconfigure and reinstall Microsoft Data Access Components (MDAC)"

echo ----------------------------------------------------------------------

echo.123 - Openfiles
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Openfiles.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k openfiles /?" /d:"List or diconnect files and folders that have been opened on a system" 

echo ----------------------------------------------------------------------

echo.124 - Osuninst
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Osuninst.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k osuninst /?" /d:"A utility to uninstall Windows XP and return to an earlier Windows OS. Can be run from a command prompt in Safe mode"

echo ----------------------------------------------------------------------

echo.125 - Path
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Path.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k path /?" /d:"Displays or sets a search path for executable files"

echo ----------------------------------------------------------------------

echo.126 - Pathping
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Pathping.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k pathping /?" /d:"Trace route plus network latency and packet loss"

echo ----------------------------------------------------------------------

echo.127 - Pause
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Pause.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k pause /?" /d:"Suspends processing of a batch program and displays the message"

echo ----------------------------------------------------------------------

echo.128 - Pentnt
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Pentnt.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k pentnt /?" /d:"Reports on whether local computer exhibits Intel Pentium Floating Point Division Error"

echo ----------------------------------------------------------------------

echo.129 - Ping
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Ping.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ping /?" /d:"Test a network connection"

echo ----------------------------------------------------------------------

echo.130 - Ping6
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Ping6.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ping6 /?" /d:"Test a  IPv6 network connection"	

echo ----------------------------------------------------------------------

echo.131 - Popd
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Popd.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k popd /?" /d:"Changes to the directory stored by the PUSHD command"

echo ----------------------------------------------------------------------

echo.132 - Powercfg
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Powercfg.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k powercfg /?" /d:"Configure power settings" 

echo ----------------------------------------------------------------------

echo.133 - Print
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Print.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k print /?" /d:"Prints a text file"

echo ----------------------------------------------------------------------

echo.134 - Prompt
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Prompt.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k prompt /?" /d:"Changes the cmd.exe command prompt"

echo ----------------------------------------------------------------------

echo.135 - Proxycfg
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Proxycfg.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k proxycfg /?" /d:"To view and change your current proxy settings"

echo ----------------------------------------------------------------------

echo.136 - Pushd
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Pushd.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k pushd /?" /d:"Stores the current directory for use by the POPD command, then changes to the specified directory"

echo ----------------------------------------------------------------------

echo.137 - Qappsrv
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Qappsrv.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k qappsrv /?" /d:"Displays the available application terminal servers on the network"

echo ----------------------------------------------------------------------

echo.138 - Qprocess
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Qprocess.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k qprocess /?" /d:"Displays information about processes"

echo ----------------------------------------------------------------------

echo.139 - Qwinsta
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Qwinsta.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k qwinsta /?" /d:"Displays information about Terminal Sessions"

echo ----------------------------------------------------------------------

echo.140 - Rasautou
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Rasautou.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k rasautou /?" /d:"A program that allows remote dial-up connections between PCs"

echo ----------------------------------------------------------------------

echo.141 - Rasdial
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Rasdial.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k rasdial /?" /d:"Manage RAS connections" 

echo ----------------------------------------------------------------------

echo.142 - Rcp
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Rcp.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k rcp /?" /d:"Copies files to and from computer running the RCP service"

echo ----------------------------------------------------------------------

echo.143 - Rd
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Rd.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k rd /?" /d:"Removes a directory"

echo ----------------------------------------------------------------------

echo.144- Recover
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Recover.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k recover /?" /d:"Recover readable information from a bad or defective disk"

echo ----------------------------------------------------------------------

echo.145 - Redir
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Redir.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k redir /?" /d:"A Win16 network redirector"

echo ----------------------------------------------------------------------

echo.146 - Reg
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Reg.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k reg /?" /d:"Console Registry Tool for Windows"

echo ----------------------------------------------------------------------

echo.147 - Regsvr32
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Regsvr32.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k regsvr32 /?" /d:"Register or unregister a DLL"

echo ----------------------------------------------------------------------

echo.148 - Regwiz
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Regwiz.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k regwiz /?" /d:"Automates the process of registering your XP operating system"

echo ----------------------------------------------------------------------

echo.149 - Relog
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Relog.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k relog /?" /d:"Creates new performance logs from data in existing performance logs by changing the sampling rate and or converting the file format"

echo ----------------------------------------------------------------------

echo.150 - Rem
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Rem.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k rem /?" /d:"Records comments (remarks) in a batch file or CONFIG.SYS"

echo ----------------------------------------------------------------------

echo.151 - Ren
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Ren.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ren /?" /d:"Renames a file or files"

echo ----------------------------------------------------------------------

echo.152 - Rename
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Rename.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k rename /?" /d:"Renames a file or files"

echo ----------------------------------------------------------------------

echo.153 - Replace
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Replace.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k replace /?" /d:"Replaces files"

echo ----------------------------------------------------------------------

echo.154 - Reset
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Reset.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k reset /?" /d:"A Terminal Services reset utility"

echo ----------------------------------------------------------------------

echo.155 - Rexec
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Rexec.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k rexec /?" /d:"Runs commands on remote hosts running the REXEC service" 

echo ----------------------------------------------------------------------

echo.156 - Rmdir
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Rmdir.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k rmdir /?" /d:"Removes a directory" 

echo ----------------------------------------------------------------------

echo.157 - Robocopy
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Robocopy.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k robocopy /?" /d:"Robust File and Folder Copy"

echo ----------------------------------------------------------------------

echo.158 - Route
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Route.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k route /?" /d:"Manipulates network routing tables"

echo ----------------------------------------------------------------------

echo.159 - Rsh
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Rsh.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k rsh /?" /d:"Runs commands on remote hosts running the RSH service"

echo ----------------------------------------------------------------------

echo.160 - Rsm
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Rsm.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k rsm /?" /d:"Command line interface for the Removable Storage Manager"

echo ----------------------------------------------------------------------

echo.161 - Runas
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Runas.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k runas /?" /d:"Execute a program under a different user account"

echo ----------------------------------------------------------------------

echo.162 - Rwinsta
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Rwinsta.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k rwinsta /?" /d:"Reset the session subsystem hardware and software to know initial values"

echo ----------------------------------------------------------------------

echo.163 - Sc
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Sc.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k sc /?" /d:"Used for communicating with the NT Service Controller and services"

echo ----------------------------------------------------------------------

echo.164 - Scardsvr 
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Scardsvr .lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k scardsvr /?" /d:"Smart Card Server component"

echo ----------------------------------------------------------------------

echo.165 - Schtasks
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Schtasks.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k schtasks /?" /d:"Create, delete, query, change, run and schedule tasks on a local or remote system"

echo ----------------------------------------------------------------------

echo.166 - Sdbinst
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Sdbinst.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k sdbinst /?" /d:"AppFix and AppHelp installer"

echo ----------------------------------------------------------------------

echo.167 - Secedit
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Secedit.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k secedit /?" /d:"Used to automatically create and apply templates, and analyze system security"

echo ----------------------------------------------------------------------

echo.168 - Set
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Set.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k set /?" /d:"Displays, sets, or remove cmd.exe environment variables"

echo ----------------------------------------------------------------------

echo.169 - Setlocal
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Setlocal.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k setlocal /?" /d:"Begins localization of environment changes in a batch file"

echo ----------------------------------------------------------------------

echo.170 - Setver
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Setver.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k setver /?" /d:"Sets the version number that MS-DOS reports to a program"

echo ----------------------------------------------------------------------

echo.171 - Sfc
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Sfc.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k sfc /?" /d:"Scans all protected system files and replaces incorrect versions with correct Microsoft versions"

echo ----------------------------------------------------------------------

echo.172 - Shadow
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Shadow.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k shadow /?" /d:"Monitor another Terminal Services session"

echo ----------------------------------------------------------------------

echo.173 - Shift
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Shift.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k shift /?" /d:"Changes the position of replaceable parameters in a batch file"

echo ----------------------------------------------------------------------

echo.174 - Shutdown
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Shutdown.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k shutdown /?" /d:"Shutdown the computer"

echo ----------------------------------------------------------------------

echo.175 - Sort
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Sort.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k sort /?" /d:"Sort input"

echo ----------------------------------------------------------------------

echo.176 - Start
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Start.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k start /?" /d:"Starts a separate window to run a specified program or command"

echo ----------------------------------------------------------------------

echo.177 - Subst
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Subst.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k subst /?" /d:"Associates a path with a drive letter"

echo ----------------------------------------------------------------------

echo.178 - Sysocmgr
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Sysocmgr.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k sysocmgr /?" /d:"The System Stand-alone Optional Component Manager"

echo ----------------------------------------------------------------------

echo.179 - Systeminfo
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Systeminfo.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k systeminfo /?" /d:"Query for basic system configuration information"

echo ----------------------------------------------------------------------

echo.180 - Taskkill
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Taskkill.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k taskkill /?" /d:"Ends one or more processes"

echo ----------------------------------------------------------------------

echo.181 - Tasklist
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Tasklist.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tasklist /?" /d:"Displays a list of applications and associated processes currently running on either a local or remote systems"

echo ----------------------------------------------------------------------

echo.182 - Tcmsetup
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Tcmsetup.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tcmsetup /?" /d:"Used to set up the Telephony configuration on a Windows XP client"

echo ----------------------------------------------------------------------

echo.183 - Tftp
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Tftp.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tftp /?" /d:"Transfers files to and from a remote computer running the TFTP service"

echo ----------------------------------------------------------------------

echo.184 - Time
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Time.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k time /?" /d:"Displays or sets the system time"

echo ----------------------------------------------------------------------

echo.185 - Title
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Title.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k title /?" /d:"Sets the window title for the command promt window"

echo ----------------------------------------------------------------------

echo.186 - Tlntadmn
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Tlntadmn.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tlntadmn /?" /d:"Allows to remotely manage a computer running Telnet Server"

echo ----------------------------------------------------------------------

echo.187 - Tlntsess
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Tlntsess.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tlntsess /?" /d:"Used to display the currently connected Telnet (Teletype network) sessions"

echo ----------------------------------------------------------------------

echo.188 - Tracerpt
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Tracerpt.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tracerpt /?" /d:"Processes binary Event Trace Session log files or real time streams from instrumented Event Trace providers and creates a report or a text file describing the events generated"

echo ----------------------------------------------------------------------

echo.189 - Tracert
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Tracert.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tracert /?" /d:"Trace route to a remote host"

echo ----------------------------------------------------------------------

echo.190 - Tracert6
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Tracert6.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tracert6 /?" /d:"Trace route to a remote host"

echo ----------------------------------------------------------------------

echo.191 - Tree
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Tree.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tree /?" /d:"Graphically displays the folder structure of a drive or path"

echo ----------------------------------------------------------------------

echo.192 - Tscon
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Tscon.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tscon /?" /d:"Attaches a user session to a terminal session"

echo ----------------------------------------------------------------------

echo.193 - Tscupgrd
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Tscupgrd.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tscupgrd /?" /d:"The Terminal Services setup component"

echo ----------------------------------------------------------------------

echo.194 - Tsdiscon
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Tsdiscon.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tsdiscon /?" /d:"Disconnects a terminal session"

echo ----------------------------------------------------------------------

echo.195 - Tskill
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Tskill.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tskill /?" /d:"Ends a process"

echo ----------------------------------------------------------------------

echo.196 - Tsshutdn
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Tsshutdn.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tsshutdn /?" /d:"Shut down a server in a controlled manner"

echo ----------------------------------------------------------------------

echo.197 - Type
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Type.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k type /?" /d:"Displays the contents of a text file or files"

echo ----------------------------------------------------------------------

echo.198 - Typeperf
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Typeperf.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k typeperf /?" /d:"Writes performance data to the command window or to a log file"

echo ----------------------------------------------------------------------

echo.199 - Tzchange
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Tzchange.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k tzchange /?" /d:"Utility to make timezone changes"

echo ----------------------------------------------------------------------

echo.200 - Unlodctr
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Unlodctr.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k unlodctr /?" /d:"Removes counter names and explain text for the specified extensible counter"

echo ----------------------------------------------------------------------

echo.201 - Userinit
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Userinit.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k userinit /?" /d:"Used to establish the operating environment for a user after logon"

echo ----------------------------------------------------------------------

echo.202 - Ver
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Ver.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k ver /?" /d:"Displays the Windows XP version"

echo ----------------------------------------------------------------------

echo.203 - Verify
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Verify.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k verify /?" /d:"Tells cmd.exe whether to verify that your files are written correctly to a disk"

echo ----------------------------------------------------------------------

echo.204 - Vol
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Vol.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k vol /?" /d:"Displays the disk volume and serial number, if they exist"

echo ----------------------------------------------------------------------

echo.205 - Vssadmin
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Vssadmin.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k vssadmin /?" /d:"Command ine interface for the Volume Shadow Copy Service"

echo ----------------------------------------------------------------------

echo.206 - Vwipxspx
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Vwipxspx.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k vwipxspx /?" /d:"A NetWare redirector component"

echo ----------------------------------------------------------------------

echo.207 - W32tm
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\W32tm.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k w32tm /?" /d:"Used to configure Windows Time service settings. It can also be used to diagnose problems with the time service"

echo ----------------------------------------------------------------------

echo.208 - Wmic
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Wmic.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k wmic /?" /d:"WMI Commands"

echo ----------------------------------------------------------------------

echo.209 - Wupdmgr
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Wupdmgr.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k wupdmgr /?" /d:"The Windows Update Manager for NT"

echo ----------------------------------------------------------------------

echo.210 - Xcopy
shortcut /f:"%HOMEDRIVE%%HOMEPATH%\Start Menu\Programs\Accessories\XP Command Line\Xcopy.lnk" /a:c /t:"%SYSTEMROOT%\system32\cmd.exe" /p:"/k xcopy /?" /d:"Copies files and directory trees"

echo ----------------------------------------------------------------------
echo. 
echo                                 Finish
echo.
echo ----------------------------------------------------------------------
echo.

pause

exit